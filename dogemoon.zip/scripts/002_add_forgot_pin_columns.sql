-- Added columns for forgot PIN OTP functionality
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS forgot_pin_code text,
ADD COLUMN IF NOT EXISTS forgot_pin_expires_at timestamp with time zone;
