"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface WalletState {
  address: string | null
  balance: number
  usdValue: number
  isLoading: boolean
  isUnlocked: boolean
  balanceVisible: boolean
}

interface WalletContextType {
  wallet: WalletState
  mnemonic: string | null
  setWalletAddress: (address: string | null) => void
  setMnemonic: (mnemonic: string | null) => void
  refreshBalance: () => Promise<void>
  clearWallet: () => void
  unlockWallet: (mnemonic: string) => void
  lockWallet: () => void
  toggleBalanceVisibility: () => void
}

const WalletContext = createContext<WalletContextType | undefined>(undefined)

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>({
    address: null,
    balance: 0,
    usdValue: 0,
    isLoading: false,
    isUnlocked: false,
    balanceVisible: true,
  })
  const [mnemonic, setMnemonicState] = useState<string | null>(null)

  const setWalletAddress = (address: string | null) => {
    setWallet((prev) => ({ ...prev, address }))
    if (address) {
      sessionStorage.setItem("dogemoon_address", address)
    } else {
      sessionStorage.removeItem("dogemoon_address")
    }
  }

  const setMnemonic = (newMnemonic: string | null) => {
    setMnemonicState(newMnemonic)
    setWallet((prev) => ({ ...prev, isUnlocked: !!newMnemonic }))
    if (newMnemonic) {
      localStorage.setItem("dogemoon_mnemonic", newMnemonic)
    } else {
      localStorage.removeItem("dogemoon_mnemonic")
    }
  }

  const unlockWallet = (walletMnemonic: string) => {
    setMnemonicState(walletMnemonic)
    setWallet((prev) => ({ ...prev, isUnlocked: true }))
    localStorage.setItem("dogemoon_mnemonic", walletMnemonic)
  }

  const lockWallet = () => {
    setMnemonicState(null)
    setWallet((prev) => ({ ...prev, isUnlocked: false }))
    localStorage.removeItem("dogemoon_mnemonic")
  }

  const toggleBalanceVisibility = () => {
    setWallet((prev) => {
      const newVisible = !prev.balanceVisible
      localStorage.setItem("dogemoon_balance_visible", String(newVisible))
      return { ...prev, balanceVisible: newVisible }
    })
  }

  const refreshBalance = async () => {
    if (!wallet.address) return

    setWallet((prev) => ({ ...prev, isLoading: true }))

    try {
      const { getWalletBalance, getDogecoinPrice } = await import("@/lib/dogecoin/api")
      const [balanceData, price] = await Promise.all([getWalletBalance(wallet.address), getDogecoinPrice()])

      setWallet((prev) => ({
        ...prev,
        balance: balanceData.balance,
        usdValue: balanceData.balance * price,
        isLoading: false,
      }))
    } catch (error) {
      console.error("Failed to refresh balance:", error)
      setWallet((prev) => ({ ...prev, isLoading: false }))
    }
  }

  const clearWallet = () => {
    setWallet({
      address: null,
      balance: 0,
      usdValue: 0,
      isLoading: false,
      isUnlocked: false,
      balanceVisible: true,
    })
    setMnemonicState(null)
    sessionStorage.removeItem("dogemoon_address")
    localStorage.removeItem("dogemoon_mnemonic")
  }

  useEffect(() => {
    const storedAddress = sessionStorage.getItem("dogemoon_address")
    const storedMnemonic = localStorage.getItem("dogemoon_mnemonic")
    const storedBalanceVisible = localStorage.getItem("dogemoon_balance_visible")

    if (storedAddress) {
      setWallet((prev) => ({ ...prev, address: storedAddress, isUnlocked: !!storedMnemonic }))
    }
    if (storedMnemonic) {
      setMnemonicState(storedMnemonic)
    }
    if (storedBalanceVisible !== null) {
      setWallet((prev) => ({ ...prev, balanceVisible: storedBalanceVisible === "true" }))
    }
  }, [])

  useEffect(() => {
    if (wallet.address) {
      refreshBalance()
    }
  }, [wallet.address])

  return (
    <WalletContext.Provider
      value={{
        wallet,
        mnemonic,
        setWalletAddress,
        setMnemonic,
        refreshBalance,
        clearWallet,
        unlockWallet,
        lockWallet,
        toggleBalanceVisibility,
      }}
    >
      {children}
    </WalletContext.Provider>
  )
}

export function useWallet() {
  const context = useContext(WalletContext)
  if (!context) {
    throw new Error("useWallet must be used within a WalletProvider")
  }
  return context
}
