"use client"

import { Button } from "@/components/ui/button"
import { Delete } from "lucide-react"

interface PinPadProps {
  onInput: (digit: string) => void
  disabled?: boolean
}

export function PinPad({ onInput, disabled }: PinPadProps) {
  const digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "delete"]

  return (
    <div className="grid grid-cols-3 gap-3 max-w-xs mx-auto">
      {digits.map((digit, index) => {
        if (digit === "") {
          return <div key={index} />
        }

        if (digit === "delete") {
          return (
            <Button
              key={digit}
              variant="ghost"
              className="h-16 w-full text-xl rounded-xl hover:bg-muted"
              onClick={() => onInput("delete")}
              disabled={disabled}
            >
              <Delete className="w-6 h-6" />
            </Button>
          )
        }

        return (
          <Button
            key={digit}
            variant="ghost"
            className="h-16 w-full text-2xl font-semibold rounded-xl hover:bg-muted active:bg-primary active:text-primary-foreground transition-colors"
            onClick={() => onInput(digit)}
            disabled={disabled}
          >
            {digit}
          </Button>
        )
      })}
    </div>
  )
}
