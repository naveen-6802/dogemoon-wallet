"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Send, QrCode, TrendingUp, Settings, History, Moon, Sun } from "lucide-react"
import { cn } from "@/lib/utils"
import { DogeLogo } from "@/components/doge-logo"
import { useTheme } from "@/contexts/theme-context"

const navItems = [
  { href: "/wallet", icon: Home, label: "Dashboard" },
  { href: "/wallet/send", icon: Send, label: "Send" },
  { href: "/wallet/receive", icon: QrCode, label: "Receive" },
  { href: "/wallet/history", icon: History, label: "History" },
  { href: "/wallet/market", icon: TrendingUp, label: "Market" },
  { href: "/wallet/settings", icon: Settings, label: "Settings" },
]

export function SidebarNav() {
  const pathname = usePathname()
  const { theme, toggleTheme } = useTheme()

  return (
    <aside className="hidden lg:flex flex-col w-64 min-h-screen bg-card/80 backdrop-blur-xl border-r border-border/50 sticky top-0 z-50">
      {/* Brand Header */}
      <div className="p-8 pb-4">
        <Link href="/wallet" className="flex items-center gap-4 group">
          <div className="relative">
            <div className="absolute -inset-1.5 bg-primary/20 rounded-full blur-lg opacity-0 group-hover:opacity-100 transition duration-500" />
            <DogeLogo className="w-12 h-12 relative transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110" />
          </div>
          <div className="flex flex-col">
            <h1 className="font-bold text-xl tracking-tight text-foreground">DogeMoon</h1>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse" />
            </div>
          </div>
        </Link>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 px-4 py-8 overflow-y-auto">
        <ul className="space-y-1.5">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            const Icon = item.icon
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3.5 px-4 py-3 rounded-2xl transition-all duration-300 relative group overflow-hidden",
                    isActive
                      ? "bg-primary/10 text-primary shadow-sm border border-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/40",
                  )}
                >
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-primary rounded-r-full" />
                  )}
                  <Icon
                    className={cn(
                      "w-5 h-5 transition-all duration-300 group-hover:scale-110 group-hover:rotate-3",
                      isActive ? "stroke-[2.5px] text-primary" : "stroke-[1.5px]",
                    )}
                  />
                  <span className={cn("font-semibold text-[15px] transition-colors", isActive ? "tracking-wide" : "")}>
                    {item.label}
                  </span>
                  {isActive && (
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none" />
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Footer Area */}
      <div className="p-6 mt-auto space-y-4">
        {/* Modern Theme Switcher Card */}
        <div className="p-4 rounded-3xl bg-muted/30 border border-border/40 backdrop-blur-sm group hover:border-primary/20 transition-all duration-300">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground/60">Appearance</span>
            <div className="flex items-center gap-1">
              <Sun
                className={cn(
                  "w-3 h-3 transition-colors",
                  theme === "light" ? "text-yellow-500" : "text-muted-foreground/30",
                )}
              />
              <Moon
                className={cn(
                  "w-3 h-3 transition-colors",
                  theme === "dark" ? "text-primary" : "text-muted-foreground/30",
                )}
              />
            </div>
          </div>
          <button
            onClick={toggleTheme}
            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-background/50 border border-border/20 hover:border-primary/30 transition-all group/btn"
          >
            <span className="text-xs font-semibold">{theme === "dark" ? "Dark Mode" : "Light Mode"}</span>
            <div className="w-9 h-5 rounded-full bg-muted relative p-1 flex items-center transition-colors group-hover/btn:bg-muted/80">
              <div
                className={cn(
                  "w-3 h-3 rounded-full shadow-sm transition-all duration-500",
                  theme === "dark" ? "translate-x-4 bg-primary" : "translate-x-0 bg-muted-foreground",
                )}
              />
            </div>
          </button>
        </div>
      </div>
    </aside>
  )
}
