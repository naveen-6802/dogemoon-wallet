"use client"

import { useState } from "react"
import { useWallet } from "@/contexts/wallet-context"
import { validateMnemonic, deriveWalletFromMnemonic } from "@/lib/dogecoin/crypto"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { AlertCircle, Loader2, Lock } from "lucide-react"

interface UnlockWalletModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUnlock: () => void
}

export function UnlockWalletModal({ open, onOpenChange, onUnlock }: UnlockWalletModalProps) {
  const { wallet, unlockWallet } = useWallet()
  const [mnemonic, setMnemonic] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleUnlock = async () => {
    setError(null)

    const words = mnemonic.trim().toLowerCase().split(/\s+/)
    if (words.length !== 12) {
      setError("Please enter all 12 words of your recovery phrase")
      return
    }

    const cleanMnemonic = words.join(" ")
    if (!validateMnemonic(cleanMnemonic)) {
      setError("Invalid recovery phrase. Please check your words and try again.")
      return
    }

    setIsLoading(true)

    try {
      // Verify the mnemonic matches the stored address
      const walletData = await deriveWalletFromMnemonic(cleanMnemonic)

      if (walletData.address !== wallet.address) {
        setError("This recovery phrase doesn't match your wallet address")
        setIsLoading(false)
        return
      }

      unlockWallet(cleanMnemonic)
      setMnemonic("")
      onUnlock()
      onOpenChange(false)
    } catch (err) {
      setError("Failed to unlock wallet. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
            <Lock className="w-6 h-6 text-primary" />
          </div>
          <DialogTitle className="text-center">Unlock Wallet</DialogTitle>
          <DialogDescription className="text-center">
            Enter your 12-word recovery phrase to unlock your wallet and enable sending.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <textarea
            value={mnemonic}
            onChange={(e) => {
              setMnemonic(e.target.value)
              setError(null)
            }}
            placeholder="Enter your 12-word recovery phrase..."
            className="w-full h-32 px-4 py-3 rounded-lg bg-muted border border-input text-foreground font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
          />

          {error && (
            <div className="flex items-center gap-2 text-destructive bg-destructive/10 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <p className="text-xs text-muted-foreground text-center">
            Your recovery phrase is never stored on our servers. It stays in your browser&apos;s memory only during this
            session.
          </p>

          <div className="flex gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1 bg-transparent">
              Cancel
            </Button>
            <Button onClick={handleUnlock} disabled={!mnemonic.trim() || isLoading} className="flex-1 font-semibold">
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Unlocking...
                </>
              ) : (
                "Unlock Wallet"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
