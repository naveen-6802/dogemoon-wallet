"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { X, Camera, FlashlightOff, Flashlight } from "lucide-react"
import type { BarcodeDetector } from "barcode-detector" // Declare the BarcodeDetector variable

interface QrScannerProps {
  onScan: (result: string) => void
  onClose: () => void
}

export function QrScanner({ onScan, onClose }: QrScannerProps) {
  const [error, setError] = useState<string | null>(null)
  const [isStarting, setIsStarting] = useState(true)
  const [hasFlash, setHasFlash] = useState(false)
  const [flashOn, setFlashOn] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number | null>(null)
  const scanningRef = useRef(true)

  const stopScanner = useCallback(() => {
    scanningRef.current = false
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
  }, [])

  const handleClose = useCallback(() => {
    stopScanner()
    onClose()
  }, [stopScanner, onClose])

  const toggleFlash = useCallback(async () => {
    if (!streamRef.current) return
    const track = streamRef.current.getVideoTracks()[0]
    if (track && "applyConstraints" in track) {
      try {
        await track.applyConstraints({
          advanced: [{ torch: !flashOn } as MediaTrackConstraintSet],
        })
        setFlashOn(!flashOn)
      } catch (e) {
        console.error("Flash toggle failed:", e)
      }
    }
  }, [flashOn])

  useEffect(() => {
    scanningRef.current = true

    const startScanner = async () => {
      try {
        const constraints: MediaStreamConstraints = {
          video: {
            facingMode: { ideal: "environment" },
            width: { ideal: 1280, min: 640 },
            height: { ideal: 720, min: 480 },
          },
          audio: false,
        }

        const stream = await navigator.mediaDevices.getUserMedia(constraints)

        if (!scanningRef.current) {
          stream.getTracks().forEach((track) => track.stop())
          return
        }

        streamRef.current = stream

        // Check for flash capability
        const track = stream.getVideoTracks()[0]
        const capabilities = track.getCapabilities?.() as MediaTrackCapabilities & { torch?: boolean }
        if (capabilities?.torch) {
          setHasFlash(true)
        }

        if (videoRef.current) {
          videoRef.current.srcObject = stream

          videoRef.current.onloadedmetadata = async () => {
            try {
              await videoRef.current?.play()
              setIsStarting(false)
              startScanningLoop()
            } catch (playError) {
              console.error("Video play error:", playError)
              setError("Failed to start video. Please try again.")
              setIsStarting(false)
            }
          }
        }
      } catch (err: unknown) {
        console.error("Scanner error:", err)
        const error = err as Error & { name?: string }
        if (error.name === "NotAllowedError") {
          setError("Camera access denied. Please allow camera permissions and try again.")
        } else if (error.name === "NotFoundError") {
          setError("No camera found. Please ensure your device has a camera.")
        } else if (error.name === "NotReadableError") {
          setError("Camera is in use by another application.")
        } else {
          setError("Failed to start camera. Please check permissions and try again.")
        }
        setIsStarting(false)
      }
    }

    const startScanningLoop = async () => {
      const hasBarcodeDetector = "BarcodeDetector" in window

      if (hasBarcodeDetector) {
        try {
          const BarcodeDetectorClass = (window as Window & { BarcodeDetector?: typeof BarcodeDetector })
            .BarcodeDetector!
          const barcodeDetector = new BarcodeDetectorClass({
            formats: ["qr_code"],
          })

          const scanFrame = async () => {
            if (!scanningRef.current || !videoRef.current || videoRef.current.readyState < 2) {
              if (scanningRef.current) {
                animationRef.current = requestAnimationFrame(scanFrame)
              }
              return
            }

            try {
              const barcodes = await barcodeDetector.detect(videoRef.current)
              if (barcodes.length > 0 && barcodes[0].rawValue) {
                const result = barcodes[0].rawValue
                stopScanner()
                onScan(result)
                return
              }
            } catch (e) {
              // Continue scanning on error
            }

            if (scanningRef.current) {
              animationRef.current = requestAnimationFrame(scanFrame)
            }
          }

          scanFrame()
        } catch (e) {
          // Fallback to jsQR if BarcodeDetector fails
          startJsQRFallback()
        }
      } else {
        startJsQRFallback()
      }
    }

    const startJsQRFallback = async () => {
      try {
        const jsQR = (await import("jsqr")).default

        const canvas = canvasRef.current
        if (!canvas) return
        const ctx = canvas.getContext("2d", { willReadFrequently: true })
        if (!ctx) return

        const scanFrame = () => {
          if (!scanningRef.current || !videoRef.current || videoRef.current.readyState < 2) {
            if (scanningRef.current) {
              animationRef.current = requestAnimationFrame(scanFrame)
            }
            return
          }

          const video = videoRef.current
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

          try {
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
              inversionAttempts: "dontInvert",
            })

            if (code?.data) {
              stopScanner()
              onScan(code.data)
              return
            }
          } catch (e) {
            // Continue scanning on error
          }

          if (scanningRef.current) {
            animationRef.current = requestAnimationFrame(scanFrame)
          }
        }

        scanFrame()
      } catch (e) {
        console.error("Failed to load jsQR:", e)
        setError("QR scanner failed to initialize. Please try again.")
      }
    }

    startScanner()

    return () => {
      stopScanner()
    }
  }, [onScan, stopScanner])

  return (
    <div className="fixed inset-0 bg-black z-50">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between z-10 bg-gradient-to-b from-black/70 to-transparent">
        <h2 className="text-white font-semibold">Scan QR Code</h2>
        <div className="flex items-center gap-2">
          {hasFlash && (
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleFlash}
              className="text-white hover:bg-white/20 rounded-full"
            >
              {flashOn ? <Flashlight className="w-6 h-6" /> : <FlashlightOff className="w-6 h-6" />}
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>
      </div>

      {/* Video Scanner */}
      <div className="h-full flex items-center justify-center">
        <div className="relative w-full h-full">
          <video ref={videoRef} className="w-full h-full object-cover" playsInline muted autoPlay />
          <canvas ref={canvasRef} className="hidden" />

          {/* Scanning frame overlay */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="relative w-64 h-64 sm:w-72 sm:h-72">
              {/* Corner decorations */}
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-lg" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-lg" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-lg" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-lg" />

              {/* Scanning line animation */}
              {!isStarting && !error && (
                <div className="absolute inset-x-2 top-2 h-0.5 bg-primary/80 animate-[scan_2s_ease-in-out_infinite]" />
              )}
            </div>
          </div>

          {/* Dark overlay outside scanning area */}
          <div className="absolute inset-0 pointer-events-none">
            <div
              className="absolute inset-0 bg-black/60"
              style={{
                clipPath:
                  "polygon(0 0, 100% 0, 100% 100%, 0 100%, 0 0, calc(50% - 128px) calc(50% - 128px), calc(50% - 128px) calc(50% + 128px), calc(50% + 128px) calc(50% + 128px), calc(50% + 128px) calc(50% - 128px), calc(50% - 128px) calc(50% - 128px))",
              }}
            />
          </div>

          {isStarting && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black">
              <Camera className="w-12 h-12 text-white/50 mb-4 animate-pulse" />
              <p className="text-white/70">Starting camera...</p>
            </div>
          )}

          {error && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black p-6">
              <Camera className="w-12 h-12 text-white/30 mb-4" />
              <p className="text-white text-center mb-4">{error}</p>
              <Button
                variant="outline"
                onClick={handleClose}
                className="border-white text-white hover:bg-white/10 bg-transparent"
              >
                Go Back
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Instructions */}
      <div className="absolute bottom-8 left-0 right-0 text-center bg-gradient-to-t from-black/70 to-transparent pt-8 pb-4">
        <p className="text-white/90 text-sm font-medium">Point camera at a Dogecoin QR code</p>
        <p className="text-white/60 text-xs mt-1">The code will be scanned automatically</p>
      </div>

      <style jsx global>{`
        @keyframes scan {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(248px); }
        }
      `}</style>
    </div>
  )
}
