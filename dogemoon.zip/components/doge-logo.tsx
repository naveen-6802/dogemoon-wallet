interface DogeLogoProps {
  className?: string
}

export function DogeLogo({ className = "w-12 h-12" }: DogeLogoProps) {
  return (
    <div className={`${className} relative overflow-hidden`}>
      <img
        src="https://naveen-6802.github.io/dogemoon/DogeMoon%20Wallet.png"
        alt="DogeMoon Wallet"
        className="w-full h-full object-cover"
        crossOrigin="anonymous"
      />
    </div>
  )
}
