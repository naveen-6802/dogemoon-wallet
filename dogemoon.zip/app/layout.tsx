import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { ThemeProvider } from "@/contexts/theme-context"
import { WalletProvider } from "@/contexts/wallet-context"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DogeMoon Wallet - Self-Custodial Dogecoin Wallet",
  description:
    "Secure, self-custodial Dogecoin wallet. Own your keys, own your DOGE. Create, backup, send and receive Dogecoin with ease.",
  keywords: ["dogecoin", "wallet", "crypto", "self-custodial", "doge", "DogeMoon"],
  alternates: {
    canonical: "https://dogecoin.one",
  },
  icons: {
    icon: [
      { url: "https://naveen-6802.github.io/dogemoon/f32.ico", sizes: "32x32", type: "image/x-icon" },
      { url: "https://naveen-6802.github.io/dogemoon/f64.ico", sizes: "64x64", type: "image/x-icon" },
      { url: "https://naveen-6802.github.io/dogemoon/f128.ico", sizes: "128x128", type: "image/x-icon" },
    ],
    apple: [
      { url: "https://naveen-6802.github.io/dogemoon/DogeMoon%20Wallet.png", sizes: "180x180", type: "image/png" },
    ],
  },
  openGraph: {
    title: "DogeMoon Wallet",
    description: "Your secure self-custodial Dogecoin wallet.",
    url: "https://dogecoin.one",
    siteName: "DogeMoon Wallet",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "DogeMoon Wallet",
    description: "Your secure self-custodial Dogecoin wallet.",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "DogeMoon Wallet",
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f5f0e6" },
    { media: "(prefers-color-scheme: dark)", color: "#1a1814" },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className="font-sans antialiased">
        <ThemeProvider>
          <WalletProvider>{children}</WalletProvider>
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
