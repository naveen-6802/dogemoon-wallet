"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { DogeLogo } from "@/components/doge-logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { PinPad } from "@/components/pin-pad"
import { hashPin, verifyPin } from "@/lib/dogecoin/crypto"
import { Loader2 } from "lucide-react"

export default function PinPage() {
  const [pin, setPin] = useState("")
  const [confirmPin, setConfirmPin] = useState("")
  const [step, setStep] = useState<"loading" | "enter" | "create" | "confirm">("loading")
  const [error, setError] = useState<string | null>(null)
  const [storedPinHash, setStoredPinHash] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkPinStatus()
  }, [])

  const checkPinStatus = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/auth/login")
      return
    }

    // Check if user has a PIN set
    const { data: profile } = await supabase.from("profiles").select("pin_hash").eq("id", user.id).single()

    if (profile?.pin_hash) {
      setStoredPinHash(profile.pin_hash)
      setStep("enter")
    } else {
      setStep("create")
    }
  }

  const handlePinInput = async (digit: string) => {
    if (isProcessing) return

    if (digit === "delete") {
      if (step === "confirm") {
        setConfirmPin((prev) => prev.slice(0, -1))
      } else {
        setPin((prev) => prev.slice(0, -1))
      }
      setError(null)
      return
    }

    if (step === "enter") {
      const newPin = pin + digit
      setPin(newPin)
      setError(null)

      if (newPin.length === 6) {
        setIsProcessing(true)
        const isValid = await verifyPin(newPin, storedPinHash!)

        if (isValid) {
          router.push("/wallet")
        } else {
          setError("Incorrect PIN. Try again.")
          setPin("")
        }
        setIsProcessing(false)
      }
    } else if (step === "create") {
      const newPin = pin + digit
      setPin(newPin)

      if (newPin.length === 6) {
        setStep("confirm")
      }
    } else if (step === "confirm") {
      const newConfirmPin = confirmPin + digit
      setConfirmPin(newConfirmPin)
      setError(null)

      if (newConfirmPin.length === 6) {
        if (newConfirmPin === pin) {
          setIsProcessing(true)
          await savePinToDatabase(pin)
          router.push("/wallet")
        } else {
          setError("PINs do not match. Try again.")
          setPin("")
          setConfirmPin("")
          setStep("create")
        }
      }
    }
  }

  const savePinToDatabase = async (pin: string) => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) return

    const pinHash = await hashPin(pin)

    await supabase.from("profiles").update({ pin_hash: pinHash }).eq("id", user.id)
  }

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  if (step === "loading") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between p-4">
        <div className="flex items-center gap-2">
          <DogeLogo className="w-8 h-8" />
          <span className="font-semibold text-foreground">DogeMoon</span>
        </div>
        <ThemeToggle />
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 pb-8">
        <div className="w-full max-w-sm space-y-8">
          {/* Title */}
          <div className="text-center space-y-2">
            <h1 className="text-2xl font-bold text-foreground">
              {step === "enter" ? "Enter PIN" : step === "create" ? "Create PIN" : "Confirm PIN"}
            </h1>
            <p className="text-muted-foreground text-sm">
              {step === "enter"
                ? "Enter your 6-digit PIN to unlock"
                : step === "create"
                  ? "Create a 6-digit PIN to secure your wallet"
                  : "Enter your PIN again to confirm"}
            </p>
          </div>

          {/* PIN Dots */}
          <div className="flex justify-center gap-3">
            {[...Array(6)].map((_, i) => {
              const currentPin = step === "confirm" ? confirmPin : pin
              return (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-full transition-all duration-200 ${
                    i < currentPin.length ? "bg-primary scale-110" : "bg-muted border-2 border-border"
                  }`}
                />
              )
            })}
          </div>

          {/* Error Message */}
          {error && (
            <div className="text-center">
              <p className="text-destructive text-sm font-medium">{error}</p>
            </div>
          )}

          {/* Security Warning Note */}
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-3 mt-4">
            <p className="text-xs text-amber-900 dark:text-amber-200 font-medium">
              {step === "create" || step === "confirm"
                ? "We cannot forget your pin or seed phrase, so kindly save them while creating account and wallet."
                : "We cannot forget your pin or seed phrase, so kindly save them securely."}
            </p>
          </div>

          {/* PIN Pad */}
          <PinPad onInput={handlePinInput} disabled={isProcessing} />

          {/* Logout Option */}
          {step === "enter" && (
            <div className="space-y-4 pt-4">
              <button
                onClick={handleLogout}
                className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Sign out and use different account
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
