"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { validateMnemonic, deriveWalletFromMnemonic } from "@/lib/dogecoin/crypto"
import { DogeLogo } from "@/components/doge-logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, AlertTriangle, Loader2 } from "lucide-react"
import Link from "next/link"

export default function ImportWalletPage() {
  const [mnemonic, setMnemonic] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isImporting, setIsImporting] = useState(false)
  const { setWalletAddress, setMnemonic: setContextMnemonic } = useWallet()
  const router = useRouter()

  const handleImport = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    const cleanedMnemonic = mnemonic.trim().toLowerCase().replace(/\s+/g, " ")
    const words = cleanedMnemonic.split(" ")

    if (words.length !== 12 && words.length !== 24) {
      setError("Recovery phrase must be 12 or 24 words")
      return
    }

    if (!validateMnemonic(cleanedMnemonic)) {
      setError("Invalid recovery phrase. Please check and try again.")
      return
    }

    setIsImporting(true)

    try {
      const walletData = await deriveWalletFromMnemonic(cleanedMnemonic)

      setContextMnemonic(cleanedMnemonic)
      sessionStorage.setItem("dogemoon_address", walletData.address)

      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (user) {
        await supabase
          .from("profiles")
          .update({ has_wallet: true, wallet_address: walletData.address })
          .eq("id", user.id)
      }

      setWalletAddress(walletData.address)
      router.push("/wallet")
    } catch (err) {
      setError("Failed to import wallet. Please check your recovery phrase.")
    } finally {
      setIsImporting(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="flex items-center justify-between p-4">
        <Link
          href="/wallet"
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </Link>
        <ThemeToggle />
      </header>

      <main className="px-4 pb-8">
        <div className="max-w-md mx-auto space-y-6">
          <div className="text-center space-y-2">
            <DogeLogo className="w-20 h-20 mx-auto" />
            <h1 className="text-2xl font-bold text-foreground">Import Wallet</h1>
            <p className="text-muted-foreground">Enter your 12 or 24 word recovery phrase to restore your wallet.</p>
          </div>

          {/* Warning */}
          <Card className="p-4 bg-primary/5 border-primary/20">
            <div className="flex gap-3">
              <AlertTriangle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-foreground mb-1">Security Reminder</p>
                <p className="text-muted-foreground">
                  Only import your recovery phrase on a secure device. Make sure no one is watching your screen.
                </p>
              </div>
            </div>
          </Card>

          <form onSubmit={handleImport} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Recovery Phrase</label>
              <textarea
                value={mnemonic}
                onChange={(e) => {
                  setMnemonic(e.target.value)
                  setError(null)
                }}
                placeholder="Enter your 12 or 24 word recovery phrase..."
                rows={4}
                className="w-full p-4 rounded-lg bg-muted border border-input text-foreground font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <p className="text-xs text-muted-foreground">Separate each word with a space</p>
            </div>

            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <Button
              type="submit"
              disabled={!mnemonic.trim() || isImporting}
              className="w-full h-12 text-base font-semibold"
            >
              {isImporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                "Import Wallet"
              )}
            </Button>
          </form>
        </div>
      </main>
    </div>
  )
}
