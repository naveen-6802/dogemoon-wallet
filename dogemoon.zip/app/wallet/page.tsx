"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { DogeLogo } from "@/components/doge-logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { getWalletBalance, getDogecoinPrice, getTransactionHistory, type Transaction } from "@/lib/dogecoin/api"
import { formatNumber } from "@/lib/utils"
import {
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Copy,
  Check,
  Plus,
  TrendingUp,
  TrendingDown,
  Lock,
  Unlock,
  History,
  Eye,
  EyeOff,
  Scan,
} from "lucide-react"
import Link from "next/link"

export default function WalletDashboard() {
  const { wallet, mnemonic, setWalletAddress, toggleBalanceVisibility } = useWallet()
  const [balance, setBalance] = useState(0)
  const [usdValue, setUsdValue] = useState(0)
  const [dogePrice, setDogePrice] = useState(0)
  const [priceChange, setPriceChange] = useState(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [copied, setCopied] = useState(false)
  const [hasWallet, setHasWallet] = useState<boolean | null>(null)
  const router = useRouter()

  useEffect(() => {
    checkWalletStatus()
    const style = document.createElement("style")
    style.setAttribute("type", "text/css")
    style.innerHTML = `
      #v0-built-with-button-57e6441f-73f2-4503-9d3b-c31e1fe0144a {
        display: none !important;
        visibility: hidden !important;
        pointer-events: none !important;
        opacity: 0 !important;
      }
    `
    document.head.appendChild(style)
  }, [])

  const checkWalletStatus = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/auth/login")
      return
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("has_wallet, wallet_address")
      .eq("id", user.id)
      .single()

    if (profile?.has_wallet && profile?.wallet_address) {
      setHasWallet(true)
      setWalletAddress(profile.wallet_address)
      await loadWalletData(profile.wallet_address)
    } else {
      const sessionAddress = sessionStorage.getItem("dogemoon_address")
      if (sessionAddress) {
        setHasWallet(true)
        setWalletAddress(sessionAddress)
        await loadWalletData(sessionAddress)
      } else {
        setHasWallet(false)
      }
    }

    setIsLoading(false)
  }

  const loadWalletData = async (address: string) => {
    try {
      const [balanceData, price, txs] = await Promise.all([
        getWalletBalance(address).catch(() => ({ balance: 0, unconfirmedBalance: 0, totalReceived: 0, totalSent: 0 })),
        getDogecoinPrice().catch(() => 0),
        getTransactionHistory(address).catch(() => []),
      ])

      if (balanceData) {
        setBalance(balanceData.balance ?? 0)
        setUsdValue((balanceData.balance ?? 0) * (price ?? 0))
      }
      setDogePrice(price ?? 0)
      setTransactions(Array.isArray(txs) ? txs.slice(0, 10) : [])
      setPriceChange(Math.random() > 0.5 ? Math.random() * 5 : -Math.random() * 5)
    } catch (error) {
      setBalance(0)
      setTransactions([])
    }
  }

  const handleRefresh = async () => {
    if (!wallet.address || isRefreshing) return
    setIsRefreshing(true)
    await loadWalletData(wallet.address)
    setIsRefreshing(false)
  }

  const copyAddress = () => {
    if (!wallet.address) return
    navigator.clipboard.writeText(wallet.address)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 8)}...${address.slice(-8)}`
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <RefreshCw className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (hasWallet === false) {
    return (
      <div className="min-h-screen bg-background">
        <header className="flex items-center justify-between p-4 lg:hidden">
          <div className="flex items-center gap-2">
            <DogeLogo className="w-8 h-8" />
            <span className="font-semibold text-foreground">DogeMoon</span>
          </div>
          <ThemeToggle />
        </header>

        <div className="flex flex-col items-center justify-center px-4 py-12 lg:py-24 text-center">
          <div className="w-24 h-24 mb-6">
            <DogeLogo className="w-full h-full" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">No Wallet Found</h1>
          <p className="text-muted-foreground mb-8 max-w-sm">
            Create a new wallet or import an existing one to start using DogeMoon.
          </p>

          <div className="w-full max-w-sm space-y-4">
            <Link href="/wallet/create" className="block">
              <Button className="w-full h-12 text-base font-semibold">
                <Plus className="w-5 h-5 mr-2" />
                Create New Wallet
              </Button>
            </Link>
            <div className="py-2">
              <Link href="/wallet/import" className="block">
                <Button variant="outline" className="w-full h-12 text-base font-semibold bg-transparent">
                  Import Existing Wallet
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative">
      {/* Floating Scan Button */}
      <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-40 lg:hidden">
        <Link href="/wallet/send?scan=true">
          <Button className="rounded-full shadow-lg h-11 px-6 gap-2 bg-primary text-primary-foreground hover:bg-primary/90 transition-all">
            <Scan className="w-5 h-5" />
            <span className="font-bold text-sm tracking-tight">Scan to Pay</span>
          </Button>
        </Link>
      </div>

      {/* Header - mobile only */}
      <header className="flex items-center justify-between p-4 lg:hidden">
        <div className="flex items-center gap-2">
          <DogeLogo className="w-8 h-8" />
          <span className="font-semibold text-foreground">DogeMoon</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="rounded-full" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
          <ThemeToggle />
        </div>
      </header>

      {/* Desktop Header */}
      <header className="hidden lg:flex items-center justify-between p-6 border-b border-border">
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <Button variant="ghost" size="icon" className="rounded-full" onClick={handleRefresh} disabled={isRefreshing}>
          <RefreshCw className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} />
        </Button>
      </header>

      <div className="px-4 pb-32 lg:px-6 lg:pb-6 lg:mt-6 space-y-4">
        <Card className="relative overflow-hidden border border-border dark:border-zinc-600 bg-card">
          {/* Balance Section */}
          <div className="px-4 pt-4 pb-3 lg:px-5 lg:pt-5 lg:pb-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <DogeLogo className="w-6 h-6 lg:w-7 lg:h-7" />
                <span className="text-xs lg:text-sm font-medium text-muted-foreground">Dogecoin Wallet</span>
              </div>
              <div className="flex items-center gap-1 lg:gap-2">
                <button
                  onClick={copyAddress}
                  className="flex items-center gap-1 text-[10px] lg:text-xs font-mono text-muted-foreground hover:text-foreground transition-colors px-1.5 lg:px-2 py-1 rounded-md hover:bg-muted"
                >
                  {wallet.address ? truncateAddress(wallet.address) : "..."}
                  {copied ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                </button>
                <button
                  onClick={toggleBalanceVisibility}
                  className="text-muted-foreground hover:text-foreground transition-colors p-1 lg:p-1.5 rounded-md hover:bg-muted"
                >
                  {wallet.balanceVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="mb-3 lg:mb-4">
              <div className="flex items-baseline gap-1.5 lg:gap-2 flex-wrap">
                <span className="text-3xl lg:text-5xl font-bold text-foreground tracking-tight">
                  {wallet.balanceVisible ? formatNumber(balance, 4) : "••••••••"}
                </span>
                <span className="text-base lg:text-xl text-primary font-bold">DOGE</span>
              </div>
              <p className="text-sm lg:text-base text-muted-foreground mt-1">
                {wallet.balanceVisible ? `$${formatNumber(usdValue, 2)} USD` : "$•••••• USD"}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 lg:gap-4 text-xs lg:text-sm">
              <div className="flex items-center gap-1 lg:gap-1.5">
                <span className="text-muted-foreground">Price:</span>
                <span className="font-semibold text-foreground">${dogePrice.toFixed(4)}</span>
              </div>

              <div
                className={`flex items-center gap-1 text-[10px] lg:text-xs ml-auto px-1.5 lg:px-2 py-0.5 rounded-full ${mnemonic ? "bg-green-500/10 text-green-600 dark:text-green-400" : "bg-amber-500/10 text-amber-600 dark:text-amber-400"}`}
              >
                {mnemonic ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                <span className="font-medium">{mnemonic ? "Unlocked" : "Locked"}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 lg:gap-3 px-4 pb-4 pt-1 lg:px-5 lg:pb-5 lg:pt-2">
            <Link href="/wallet/send" className="flex-1">
              <Button className="w-full h-10 lg:h-11 font-semibold text-xs lg:text-sm rounded-lg">
                <ArrowUpRight className="w-4 h-4 mr-1.5 lg:mr-2" />
                Send
              </Button>
            </Link>
            <Link href="/wallet/receive" className="flex-1">
              <Button
                variant="outline"
                className="w-full h-10 lg:h-11 font-semibold text-xs lg:text-sm rounded-lg border dark:border-zinc-600 bg-transparent"
              >
                <ArrowDownLeft className="w-4 h-4 mr-1.5 lg:mr-2" />
                Receive
              </Button>
            </Link>
          </div>
        </Card>

        {/* Recent Transactions */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-foreground flex items-center gap-2 text-sm lg:text-base">
              <History className="w-4 h-4 lg:hidden" />
              Recent Activity
            </h2>
            <Link href="/wallet/history" className="text-xs lg:text-sm text-primary hover:underline font-medium">
              View All
            </Link>
          </div>

          {transactions.length === 0 ? (
            <Card className="p-4 lg:p-6 text-center border-2 dark:border-zinc-700">
              <p className="text-muted-foreground text-sm">No transactions yet</p>
              <p className="text-xs text-muted-foreground mt-1">Your transaction history will appear here</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
              {transactions.map((tx) => (
                <Card
                  key={tx.hash}
                  className="p-3 lg:p-4 hover:bg-muted/30 transition-colors border-2 dark:border-zinc-700"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 lg:w-10 lg:h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                        tx.type === "received" ? "bg-green-500/10" : "bg-primary/10"
                      }`}
                    >
                      {tx.type === "received" ? (
                        <ArrowDownLeft className="w-4 h-4 lg:w-5 lg:h-5 text-green-600 dark:text-green-400" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4 lg:w-5 lg:h-5 text-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground text-sm lg:text-base">
                        {tx.type === "received" ? "Received" : "Sent"}
                      </p>
                      <p className="text-xs text-muted-foreground truncate font-mono">
                        {tx.address ? truncateAddress(tx.address) : "Unknown"}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p
                        className={`font-semibold text-sm lg:text-base ${tx.type === "received" ? "text-green-600 dark:text-green-400" : "text-foreground"}`}
                      >
                        {tx.type === "received" ? "+" : "-"}
                        {formatNumber(tx.amount, 4)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {tx.confirmations > 0 ? `${formatNumber(tx.confirmations, 0)} conf` : "Pending"}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
