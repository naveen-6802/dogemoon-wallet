import Link from "next/link"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Shield, Eye, Lock, AlertTriangle, Server, Key } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="flex items-center p-4 lg:p-6 lg:border-b lg:border-border">
        <Link
          href="/wallet/settings"
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </Link>
      </header>

      <main className="px-4 pb-8 max-w-2xl mx-auto lg:px-6 lg:mt-10">
        <h1 className="text-2xl font-bold text-foreground mb-6">Terms of Service & Security</h1>

        {/* Security Notice Banner */}
        <Card className="p-4 mb-6 bg-primary/5 border-primary/20">
          <div className="flex items-start gap-3">
            <Shield className="w-6 h-6 text-primary shrink-0 mt-0.5" />
            <div>
              <h2 className="font-semibold text-foreground mb-1">Your Security is Our Priority</h2>
              <p className="text-sm text-muted-foreground">
                DogeMoon Wallet is designed with security-first principles. Read below to understand how we protect your
                assets.
              </p>
            </div>
          </div>
        </Card>

        <div className="space-y-6">
          {/* What We DON'T Store */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center">
                <Eye className="w-5 h-5 text-success" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">What We DO NOT Store</h2>
            </div>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-success font-bold">✓</span>
                <span>
                  <strong className="text-foreground">Recovery Phrase (Seed Phrase):</strong> Your 12-word recovery
                  phrase is NEVER stored on our servers. It exists only on your device during your session and is
                  cleared when you log out.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-success font-bold">✓</span>
                <span>
                  <strong className="text-foreground">Private Keys:</strong> Your private keys are generated locally on
                  your device and are never transmitted to or stored on our servers.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-success font-bold">✓</span>
                <span>
                  <strong className="text-foreground">Transaction Signing:</strong> All transactions are signed locally
                  on your device. We never have access to sign transactions on your behalf.
                </span>
              </li>
            </ul>
          </Card>

          {/* What We DO Store */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Server className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">What We DO Store</h2>
            </div>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">•</span>
                <span>
                  <strong className="text-foreground">Email Address:</strong> For account authentication and recovery
                  purposes only.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">•</span>
                <span>
                  <strong className="text-foreground">Hashed PIN:</strong> Your 6-digit PIN is cryptographically hashed
                  before storage. We cannot see or recover your actual PIN.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">•</span>
                <span>
                  <strong className="text-foreground">Public Wallet Address:</strong> Your Dogecoin address (starting
                  with 'D') for displaying your balance. This is public information on the blockchain.
                </span>
              </li>
            </ul>
          </Card>

          {/* Self-Custody Warning */}
          <Card className="p-6 border-destructive/30 bg-destructive/5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-destructive" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">Critical Security Warning</h2>
            </div>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-destructive font-bold">!</span>
                <span>
                  <strong className="text-foreground">Backup Your Recovery Phrase:</strong> Write down your 12-word
                  recovery phrase and store it in a secure, offline location. This is the ONLY way to recover your
                  wallet.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-destructive font-bold">!</span>
                <span>
                  <strong className="text-foreground">No Recovery Without Phrase:</strong> If you lose your recovery
                  phrase, there is NO way to recover your wallet or funds. We cannot help you recover lost wallets.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-destructive font-bold">!</span>
                <span>
                  <strong className="text-foreground">Never Share Your Phrase:</strong> Anyone with your recovery phrase
                  can access and steal all your funds. Never share it with anyone, including DogeMoon support.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-destructive font-bold">!</span>
                <span>
                  <strong className="text-foreground">Beware of Phishing:</strong> DogeMoon will NEVER ask for your
                  recovery phrase via email, chat, or any other means.
                </span>
              </li>
            </ul>
          </Card>

          {/* How Security Works */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Lock className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">How Our Security Works</h2>
            </div>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">1.</span>
                <span>
                  <strong className="text-foreground">BIP39 Standard:</strong> We use industry-standard BIP39 mnemonic
                  generation for creating recovery phrases.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">2.</span>
                <span>
                  <strong className="text-foreground">BIP44 Derivation:</strong> Your Dogecoin addresses are derived
                  using the standard BIP44 path (m/44&apos;/3&apos;/0&apos;/0/0).
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">3.</span>
                <span>
                  <strong className="text-foreground">Client-Side Cryptography:</strong> All cryptographic operations
                  happen in your browser, never on our servers.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">4.</span>
                <span>
                  <strong className="text-foreground">Secure Authentication:</strong> Your account is protected by email
                  verification and PIN authentication.
                </span>
              </li>
            </ul>
          </Card>

          {/* Additional Terms */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                <Key className="w-5 h-5 text-muted-foreground" />
              </div>
              <h2 className="text-lg font-semibold text-foreground">Additional Terms</h2>
            </div>
            <div className="space-y-4 text-sm text-muted-foreground">
              <div>
                <h3 className="font-semibold text-foreground mb-1">Risk Acknowledgment</h3>
                <p>
                  Cryptocurrency transactions are irreversible. You acknowledge the risks associated with using
                  cryptocurrency, including market volatility and potential loss of funds.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">No Financial Advice</h3>
                <p>
                  DogeMoon does not provide financial, investment, or legal advice. Market data is for informational
                  purposes only.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Limitation of Liability</h3>
                <p>
                  DogeMoon is provided &quot;as is&quot; without warranties. We are not liable for any damages from use
                  of this application or loss of funds.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Updates</h3>
                <p>We may update these terms from time to time. Continued use constitutes acceptance of changes.</p>
              </div>
            </div>
          </Card>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-6">Last updated: January 2025</p>
      </main>
    </div>
  )
}
