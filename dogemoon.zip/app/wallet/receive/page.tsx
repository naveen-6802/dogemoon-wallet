"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { DogeLogo } from "@/components/doge-logo"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Copy, Check, Share2, Download } from "lucide-react"
import { QRCodeSVG } from "qrcode.react"

const DOGE_LOGO_URL = "https://naveen-6802.github.io/dogemoon/DogeMoon%20Wallet.png"

export default function ReceivePage() {
  const { wallet, setWalletAddress } = useWallet()
  const [amount, setAmount] = useState("")
  const [copied, setCopied] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [logoLoaded, setLogoLoaded] = useState(false)
  const router = useRouter()

  useEffect(() => {
    loadAddress()
    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => setLogoLoaded(true)
    img.onerror = () => setLogoLoaded(false)
    img.src = DOGE_LOGO_URL
  }, [])

  const loadAddress = async () => {
    const sessionAddress = sessionStorage.getItem("dogemoon_address")
    if (sessionAddress) {
      setWalletAddress(sessionAddress)
      setIsLoading(false)
      return
    }

    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/auth/login")
      return
    }

    const { data: profile } = await supabase.from("profiles").select("wallet_address").eq("id", user.id).single()

    if (profile?.wallet_address) {
      setWalletAddress(profile.wallet_address)
    }
    setIsLoading(false)
  }

  const copyAddress = () => {
    if (!wallet.address) return
    navigator.clipboard.writeText(wallet.address)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const shareAddress = async () => {
    if (!wallet.address) return

    try {
      await navigator.share({
        title: "DogeMoon Wallet Address",
        text: `Send DOGE to: ${wallet.address}${amount ? `\nAmount: ${amount} DOGE` : ""}`,
      })
    } catch {
      copyAddress()
    }
  }

  const downloadQR = () => {
    const svg = document.getElementById("qr-code")
    if (!svg) return

    const svgData = new XMLSerializer().serializeToString(svg)
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    const img = new Image()
    const logoImg = new Image()
    logoImg.crossOrigin = "anonymous"
    logoImg.src = DOGE_LOGO_URL

    img.onload = () => {
      canvas.width = 1000 // High resolution for download
      canvas.height = 1000

      if (ctx) {
        // Draw white background
        ctx.fillStyle = "white"
        ctx.fillRect(0, 0, canvas.width, canvas.height)

        // Draw QR code
        ctx.drawImage(img, 50, 50, 900, 900)

        // Draw Logo if loaded
        if (logoLoaded) {
          const logoSize = 180
          const x = (canvas.width - logoSize) / 2
          const y = (canvas.height - logoSize) / 2

          // Draw white square behind logo (excavate effect)
          ctx.fillStyle = "white"
          ctx.fillRect(x - 10, y - 10, logoSize + 20, logoSize + 20)

          ctx.drawImage(logoImg, x, y, logoSize, logoSize)
        }
      }

      const pngFile = canvas.toDataURL("image/png")
      const downloadLink = document.createElement("a")
      downloadLink.download = "dogemoon-address.png"
      downloadLink.href = pngFile
      downloadLink.click()
    }

    img.crossOrigin = "anonymous"
    img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgData)))
  }

  const qrValue = amount ? `dogecoin:${wallet.address}?amount=${amount}` : `dogecoin:${wallet.address}`

  if (isLoading || !wallet.address) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <DogeLogo className="w-12 h-12 animate-pulse" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="p-4 lg:p-6 lg:border-b lg:border-border max-w-md mx-auto w-full">
        <h1 className="text-xl lg:text-2xl font-bold text-foreground text-center lg:text-left">Receive DOGE</h1>
      </header>

      <main className="px-4 pb-24 lg:px-6 lg:pb-6 max-w-md mx-auto w-full space-y-6 mt-6 lg:mt-10">
        {/* QR Code */}
        <Card className="p-6 flex flex-col items-center">
          <div className="bg-white p-4 rounded-xl mb-4 relative">
            <QRCodeSVG
              id="qr-code"
              value={qrValue}
              size={200}
              level="H"
              includeMargin={true}
              imageSettings={
                logoLoaded
                  ? {
                      src: DOGE_LOGO_URL,
                      x: undefined,
                      y: undefined,
                      height: 40,
                      width: 40,
                      excavate: true,
                    }
                  : undefined
              }
            />
          </div>
          <p className="text-sm text-muted-foreground text-center">Scan this QR code to send DOGE to this wallet</p>
        </Card>

        {/* Amount Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Request Amount (Optional)</label>
          <Input
            type="number"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="h-12 text-lg font-mono"
          />
          <p className="text-xs text-muted-foreground">Add an amount to include in the QR code</p>
        </div>

        {/* Address Display */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Your Dogecoin Address</label>
          <Card className="p-4">
            <p className="font-mono text-sm text-foreground break-all">{wallet.address}</p>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-3 gap-3">
          <Button variant="outline" onClick={copyAddress} className="h-12 flex-col gap-1 bg-transparent">
            {copied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
            <span className="text-xs">{copied ? "Copied!" : "Copy"}</span>
          </Button>
          <Button variant="outline" onClick={shareAddress} className="h-12 flex-col gap-1 bg-transparent">
            <Share2 className="w-5 h-5" />
            <span className="text-xs">Share</span>
          </Button>
          <Button variant="outline" onClick={downloadQR} className="h-12 flex-col gap-1 bg-transparent">
            <Download className="w-5 h-5" />
            <span className="text-xs">Save QR</span>
          </Button>
        </div>
      </main>
    </div>
  )
}
