"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { useTheme } from "@/contexts/theme-context"
import { DogeLogo } from "@/components/doge-logo"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import {
  Moon,
  Sun,
  Shield,
  Key,
  Trash2,
  LogOut,
  ChevronRight,
  Info,
  FileText,
  Mail,
  ExternalLink,
  AlertTriangle,
  HelpCircle,
  ChevronDown,
  Lock,
} from "lucide-react"

const FAQS = [
  {
    question: "Why is my wallet locked?",
    answer:
      "Your wallet is locked for security. To send DOGE, you must enter your recovery phrase or PIN to unlock it during this session.",
  },
  {
    question: "How do I unlock my wallet?",
    answer:
      "Go to Settings > Backup Wallet > Click on Import Wallet > Enter Your Recovery Phrase > Import wallet. This is due to security purpose, whenever you sign out and sign in into new device/new session, it always asks your seed phrase because we do not store it on our servers.",
  },
  {
    question: "Is this wallet safe to use?",
    answer:
      "Yes, DogeMoon is a self-custodial wallet. We never store your recovery phrase or private keys on our servers.",
  },
  {
    question: "What if I lose my recovery phrase?",
    answer:
      "Since we don't store your phrase, we cannot recover it for you. Always keep a physical backup of your 12-word recovery phrase.",
  },
  {
    question: "Can I use my wallet on multiple devices?",
    answer:
      "Yes! Simply sign in with your email and then 'Import Existing Wallet' using your 12-word recovery phrase on any new device.",
  },
  {
    question: "Are there any fees?",
    answer: "DogeMoon doesn't charge fees, but the Dogecoin network requires a small fee (0.01 DOGE) per transaction.",
  },
  {
    question: "How do I change my PIN?",
    answer: "You can change your 6-digit PIN in the Security section of these settings.",
  },
  {
    question: "Where are my Dogecoins stored?",
    answer:
      "Your DOGE is stored on the Dogecoin blockchain. Our app is just an interface to manage them using your private keys.",
  },
  {
    question: "How do I backup my wallet?",
    answer: "Go to Settings > Backup Wallet to view your 12-word recovery phrase. Write it down and store it safely.",
  },
  {
    question: "What is self-custodial?",
    answer:
      "It means YOU are in full control of your funds. No third party (including us) can access or freeze your Dogecoin.",
  },
]

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme()
  const { wallet, clearWallet } = useWallet()
  const [userEmail, setUserEmail] = useState<string | null>(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null)
  const router = useRouter()

  useEffect(() => {
    loadUserData()
  }, [])

  const loadUserData = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      setUserEmail(user.email || null)
    }
  }

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    clearWallet()
    sessionStorage.clear()
    router.push("/")
  }

  const handleDeleteWallet = async () => {
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (user) {
      // Clear wallet from database
      await supabase.from("profiles").update({ has_wallet: false, wallet_address: null }).eq("id", user.id)
    }

    // Clear local data
    clearWallet()
    sessionStorage.clear()
    router.push("/wallet")
  }

  const truncateAddress = (address: string) => {
    if (!address) return "No wallet"
    return `${address.slice(0, 10)}...${address.slice(-10)}`
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="p-4">
        <h1 className="text-xl font-bold text-foreground text-center">Settings</h1>
      </header>

      <main className="px-4 pb-24 space-y-6">
        <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-4 mb-2">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-xs font-semibold text-blue-500 uppercase mb-1">Security Note</p>
              <p className="text-xs text-muted-foreground">
                Your dogecoins are stored on the Dogecoin blockchain, not on our servers. Even if our website is
                offline, your funds are safe and accessible in any other wallet using your recovery phrase.
              </p>
            </div>
          </div>
        </div>

        {/* Account Section */}
        <div>
          <h2 className="text-sm font-medium text-muted-foreground mb-2 px-1">Account</h2>
          <Card className="divide-y divide-border">
            <div className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium text-foreground truncate">{userEmail || "Not signed in"}</p>
              </div>
            </div>

            <div className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <DogeLogo className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-muted-foreground">Wallet Address</p>
                <p className="font-mono text-sm text-foreground truncate">
                  {wallet.address ? truncateAddress(wallet.address) : "No wallet"}
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Preferences Section */}
        <div>
          <h2 className="text-sm font-medium text-muted-foreground mb-2 px-1">Preferences</h2>
          <Card className="divide-y divide-border">
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {theme === "dark" ? (
                  <Moon className="w-5 h-5 text-muted-foreground" />
                ) : (
                  <Sun className="w-5 h-5 text-muted-foreground" />
                )}
                <div>
                  <p className="font-medium text-foreground">Dark Mode</p>
                  <p className="text-sm text-muted-foreground">Use dark theme</p>
                </div>
              </div>
              <Switch checked={theme === "dark"} onCheckedChange={toggleTheme} />
            </div>
          </Card>
        </div>

        {/* Security Section */}
        <div>
          <h2 className="text-sm font-medium text-muted-foreground mb-2 px-1">Security</h2>
          <Card className="divide-y divide-border">
            <Link href="/wallet/settings/change-password">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium text-foreground">Change Password</p>
                    <p className="text-sm text-muted-foreground">Update account password</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Link>

            <Link href="/wallet/settings/change-pin">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium text-foreground">Change PIN</p>
                    <p className="text-sm text-muted-foreground">Update your 6-digit PIN</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Link>

            <Link href="/wallet/settings/backup">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Key className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium text-foreground">Backup Wallet</p>
                    <p className="text-sm text-muted-foreground">View recovery phrase</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Link>
          </Card>
        </div>

        {/* About Section */}
        <div>
          <h2 className="text-sm font-medium text-muted-foreground mb-2 px-1">About & Help</h2>
          <Card className="divide-y divide-border">
            <Link href="/wallet/about">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Info className="w-5 h-5 text-muted-foreground" />
                  <p className="font-medium text-foreground">About DogeMoon</p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Link>

            <div className="p-4 space-y-3">
              <div className="flex items-center gap-3 mb-1">
                <HelpCircle className="w-5 h-5 text-muted-foreground" />
                <p className="font-medium text-foreground">Quick FAQ</p>
              </div>
              <div className="space-y-2">
                {FAQS.map((faq, index) => (
                  <div key={index} className="border border-border rounded-lg overflow-hidden">
                    <button
                      className="w-full px-3 py-2 flex items-center justify-between text-left bg-muted/30"
                      onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                    >
                      <span className="text-xs font-medium text-foreground">{faq.question}</span>
                      {openFaqIndex === index ? (
                        <ChevronDown className="w-3 h-3 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="w-3 h-3 text-muted-foreground" />
                      )}
                    </button>
                    {openFaqIndex === index && (
                      <div className="px-3 py-2 bg-background border-t border-border">
                        <p className="text-xs text-muted-foreground">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <a href="https://dogecoin.com" target="_blank" rel="noopener noreferrer">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <ExternalLink className="w-5 h-5 text-muted-foreground" />
                  <p className="font-medium text-foreground">Dogecoin.com</p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </a>

            <Link href="/wallet/terms">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-muted-foreground" />
                  <p className="font-medium text-foreground">Terms of Service</p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Link>
          </Card>
        </div>

        {/* Danger Zone */}
        <div>
          <h2 className="text-sm font-medium text-destructive mb-2 px-1">Danger Zone</h2>
          <Card className="divide-y divide-border border-destructive/20">
            <button onClick={() => setShowDeleteConfirm(true)} className="w-full p-4 flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-destructive" />
              <div className="text-left">
                <p className="font-medium text-destructive">Delete Wallet</p>
                <p className="text-sm text-muted-foreground">Remove wallet from this device</p>
              </div>
            </button>

            <button onClick={handleLogout} className="w-full p-4 flex items-center gap-3">
              <LogOut className="w-5 h-5 text-muted-foreground" />
              <p className="font-medium text-foreground">Sign Out</p>
            </button>
          </Card>
        </div>

        {/* Version */}
        <p className="text-center text-xs text-muted-foreground">DogeMoon Wallet v1.0.0</p>
      </main>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-sm p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-destructive" />
              </div>
              <div>
                <h3 className="font-bold text-foreground">Delete Wallet?</h3>
                <p className="text-sm text-muted-foreground">This action cannot be undone</p>
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-6">
              Make sure you have backed up your recovery phrase. Without it, you will lose access to your funds forever.
            </p>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowDeleteConfirm(false)} className="flex-1 bg-transparent">
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDeleteWallet} className="flex-1">
                Delete Wallet
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}
