"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { verifyPin } from "@/lib/dogecoin/crypto"
import { DogeLogo } from "@/components/doge-logo"
import { PinPad } from "@/components/pin-pad"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Eye, EyeOff, Copy, Check, AlertTriangle } from "lucide-react"

type Step = "verify" | "display"

export default function BackupPage() {
  const [step, setStep] = useState<Step>("verify")
  const [pin, setPin] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [showMnemonic, setShowMnemonic] = useState(false)
  const [copied, setCopied] = useState(false)
  const [mnemonic, setMnemonic] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if mnemonic exists in session or local storage
    const sessionMnemonic = sessionStorage.getItem("dogemoon_mnemonic")
    const localMnemonic = localStorage.getItem("dogemoon_mnemonic")
    const storedMnemonic = sessionMnemonic || localMnemonic

    if (storedMnemonic) {
      setMnemonic(storedMnemonic)
    }
  }, [])

  const handlePinInput = async (digit: string) => {
    if (isProcessing) return

    if (digit === "delete") {
      setPin((prev) => prev.slice(0, -1))
      setError(null)
      return
    }

    const newPin = pin + digit
    setPin(newPin)
    setError(null)

    if (newPin.length === 6) {
      setIsProcessing(true)
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (user) {
        const { data: profile } = await supabase.from("profiles").select("pin_hash").eq("id", user.id).single()

        if (profile?.pin_hash) {
          const isValid = await verifyPin(newPin, profile.pin_hash)
          if (isValid) {
            setStep("display")
          } else {
            setError("Incorrect PIN")
            setPin("")
          }
        }
      }
      setIsProcessing(false)
    }
  }

  const copyMnemonic = () => {
    if (!mnemonic) return
    navigator.clipboard.writeText(mnemonic)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (!mnemonic) {
    return (
      <div className="min-h-screen bg-background">
        <header className="flex items-center p-4">
          <Link
            href="/wallet/settings"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Back</span>
          </Link>
        </header>

        <main className="px-4 py-8">
          <div className="max-w-md mx-auto text-center">
            <AlertTriangle className="w-16 h-16 text-primary mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-2">Recovery Phrase Unavailable</h1>
            <p className="text-muted-foreground mb-6">
              Your recovery phrase is only available during the current session. Please import your wallet again to view
              it.
            </p>
            <Link href="/wallet/import">
              <Button>Import Wallet</Button>
            </Link>
          </div>
        </main>
      </div>
    )
  }

  if (step === "verify") {
    return (
      <div className="min-h-screen bg-background">
        <header className="flex items-center p-4">
          <Link
            href="/wallet/settings"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Back</span>
          </Link>
        </header>

        <main className="flex flex-col items-center justify-center px-4 py-8">
          <div className="w-full max-w-sm space-y-8">
            <div className="text-center space-y-2">
              <DogeLogo className="w-16 h-16 mx-auto" />
              <h1 className="text-2xl font-bold text-foreground">Enter PIN</h1>
              <p className="text-muted-foreground text-sm">Enter your PIN to view your recovery phrase</p>
            </div>

            <div className="flex justify-center gap-3">
              {[...Array(6)].map((_, i) => (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-full transition-all duration-200 ${
                    i < pin.length ? "bg-primary scale-110" : "bg-muted border-2 border-border"
                  }`}
                />
              ))}
            </div>

            {error && (
              <div className="text-center">
                <p className="text-destructive text-sm font-medium">{error}</p>
              </div>
            )}

            <PinPad onInput={handlePinInput} disabled={isProcessing} />
          </div>
        </main>
      </div>
    )
  }

  const words = mnemonic.split(" ")

  return (
    <div className="min-h-screen bg-background">
      <header className="flex items-center p-4">
        <Link
          href="/wallet/settings"
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </Link>
      </header>

      <main className="px-4 pb-8">
        <div className="max-w-md mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-2xl font-bold text-foreground">Recovery Phrase</h1>
            <p className="text-muted-foreground">Write down these words and store them safely.</p>
          </div>

          <Card className="p-4 bg-destructive/5 border-destructive/20">
            <div className="flex gap-3">
              <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                Never share your recovery phrase. Anyone with these words can access your funds.
              </p>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-muted-foreground">Your Recovery Phrase</span>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => setShowMnemonic(!showMnemonic)}>
                  {showMnemonic ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
                <Button variant="ghost" size="sm" onClick={copyMnemonic}>
                  {copied ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {words.map((word, index) => (
                <div key={index} className="bg-muted rounded-lg p-2 text-center">
                  <span className="text-xs text-muted-foreground">{index + 1}.</span>{" "}
                  <span className={`font-mono ${showMnemonic ? "" : "blur-sm select-none"}`}>{word}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}
