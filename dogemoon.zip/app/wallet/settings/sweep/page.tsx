"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Wand2, ShieldAlert, CheckCircle2, ArrowRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { getAddressFromWIF, signTransactionWithWIF, validateDogecoinAddress } from "@/lib/dogecoin/crypto"
import { getWalletBalance, createTransaction, broadcastTransaction } from "@/lib/dogecoin/api"
import { useToast } from "@/hooks/use-toast"

export default function SweepWalletPage() {
  const [wif, setWif] = useState("")
  const [destination, setDestination] = useState("")
  const [step, setStep] = useState<"entry" | "confirm" | "success">("entry")
  const [isLoading, setIsLoading] = useState(false)
  const [sweepData, setSweepData] = useState<{ address: string; balance: number } | null>(null)
  const { toast } = useToast()
  const router = useRouter()

  const handleCheckWIF = async () => {
    if (!wif) return
    setIsLoading(true)
    try {
      const address = getAddressFromWIF(wif)
      const data = await getWalletBalance(address)

      if (data.balance <= 0.01) {
        toast({
          title: "Insufficient Balance",
          description: "This wallet doesn't have enough DOGE to sweep (minimum 0.01 DOGE for fees).",
          variant: "destructive",
        })
        return
      }

      setSweepData({ address, balance: data.balance })
      setStep("confirm")
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Invalid WIF private key",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSweep = async () => {
    if (!sweepData || !validateDogecoinAddress(destination)) {
      toast({
        title: "Invalid Address",
        description: "Please enter a valid destination address.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      // Deduct fee (approx 0.01 DOGE)
      const sweepAmount = sweepData.balance - 0.015
      const txSkeleton = await createTransaction(sweepData.address, destination, sweepAmount)
      const signatures = signTransactionWithWIF(txSkeleton, wif)
      const pubKey = getAddressFromWIF(wif) // Simplified for the payload

      await broadcastTransaction(txSkeleton, signatures, [pubKey])
      setStep("success")
    } catch (error: any) {
      toast({ title: "Sweep Failed", description: error.message, variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-md mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">Sweep Wallet</h1>
        </div>

        {step === "entry" && (
          <Card className="p-6 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Private Key (WIF)</label>
              <Input
                type="password"
                placeholder="Enter your private key starting with 'Q' or '6'..."
                value={wif}
                onChange={(e) => setWif(e.target.value)}
                className="font-mono text-sm"
              />
              <p className="text-[10px] text-muted-foreground">
                Sweeping transfers all funds from an old wallet to a new one. This process requires a private key in WIF
                format.
              </p>
            </div>
            <Button className="w-full h-12 rounded-xl gap-2" onClick={handleCheckWIF} disabled={isLoading || !wif}>
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
              Check Balance
            </Button>
          </Card>
        )}

        {step === "confirm" && sweepData && (
          <Card className="p-6 space-y-6">
            <div className="flex flex-col items-center text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                <ShieldAlert className="w-6 h-6 text-primary" />
              </div>
              <h2 className="font-bold">Ready to Sweep</h2>
              <p className="text-2xl font-bold text-primary">{sweepData.balance.toFixed(2)} DOGE</p>
              <p className="text-xs text-muted-foreground break-all">From: {sweepData.address}</p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Destination Address</label>
              <Input
                placeholder="Doge address to receive funds..."
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="font-mono text-sm"
              />
            </div>

            <Button className="w-full h-12 rounded-xl gap-2" onClick={handleSweep} disabled={isLoading || !destination}>
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
              Sweep Now
            </Button>
            <Button variant="ghost" className="w-full" onClick={() => setStep("entry")} disabled={isLoading}>
              Back
            </Button>
          </Card>
        )}

        {step === "success" && (
          <Card className="p-8 text-center space-y-6">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10 text-green-500" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-bold">Sweep Successful!</h2>
                <p className="text-sm text-muted-foreground">
                  Your funds are being transferred to the destination address. This may take a few minutes to confirm on
                  the blockchain.
                </p>
              </div>
            </div>
            <Button className="w-full rounded-xl" onClick={() => router.push("/wallet")}>
              Return to Dashboard
            </Button>
          </Card>
        )}
      </div>
    </div>
  )
}
