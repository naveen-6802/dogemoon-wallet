"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ArrowLeft, CheckCircle2 } from "lucide-react"

type PasswordStep = "pin" | "old-password" | "new-password" | "success"

export default function ChangePasswordPage() {
  const [step, setStep] = useState<PasswordStep>("pin")
  const [pin, setPin] = useState("")
  const [oldPassword, setOldPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return

    try {
      if (step === "pin") {
        setIsLoading(true)
        const { data: profile } = await supabase.from("profiles").select("pin_hash").eq("id", user.id).single()
        const { verifyPin } = await import("@/lib/dogecoin/crypto")

        if (profile?.pin_hash && (await verifyPin(pin, profile.pin_hash))) {
          setStep("old-password")
        } else {
          throw new Error("Incorrect PIN")
        }
      } else if (step === "old-password") {
        setIsLoading(true)
        // Verify current password by attempting a sign-in check (standard Supabase pattern for old password verification)
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: user.email!,
          password: oldPassword,
        })

        if (signInError) throw new Error("Incorrect current password")
        setStep("new-password")
      } else if (step === "new-password") {
        if (newPassword !== confirmPassword) throw new Error("Passwords do not match")

        setIsLoading(true)
        const { error: updateError } = await supabase.auth.updateUser({
          password: newPassword,
        })

        if (updateError) throw updateError
        setStep("success")
        setTimeout(() => router.push("/wallet/settings"), 2000)
      }
    } catch (err: any) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="p-4 lg:p-6 lg:border-b lg:border-border">
        <div className="max-w-md mx-auto w-full flex items-center justify-between">
          <Link
            href="/wallet/settings"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back</span>
          </Link>
          <h1 className="text-lg font-bold">Change Password</h1>
          <div className="w-10" /> {/* Spacer */}
        </div>
      </header>

      <main className="flex-1 px-4 py-8 max-w-md mx-auto w-full">
        <Card className="border-border">
          <CardHeader className="text-center space-y-2">
            <CardTitle className="text-xl font-bold">Account Password</CardTitle>
            <CardDescription>Update your DogeMoon account password</CardDescription>
          </CardHeader>
          <CardContent>
            {step === "success" ? (
              <div className="flex flex-col items-center py-4 space-y-4">
                <CheckCircle2 className="w-12 h-12 text-success" />
                <p className="text-sm font-medium text-success">Password updated successfully!</p>
              </div>
            ) : (
              <form onSubmit={handleUpdate} className="space-y-4">
                {step === "pin" && (
                  <div className="space-y-2">
                    <Label htmlFor="pin">PIN Verification</Label>
                    <Input
                      id="pin"
                      type="password"
                      placeholder="••••"
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      required
                      className="h-12"
                    />
                  </div>
                )}
                {step === "old-password" && (
                  <div className="space-y-2">
                    <Label htmlFor="oldPassword">Old Password</Label>
                    <Input
                      id="oldPassword"
                      type="password"
                      placeholder="••••••••"
                      value={oldPassword}
                      onChange={(e) => setOldPassword(e.target.value)}
                      required
                      className="h-12"
                    />
                  </div>
                )}
                {step === "new-password" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        placeholder="••••••••"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                        className="h-12"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="••••••••"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        className="h-12"
                      />
                    </div>
                  </>
                )}

                {error && (
                  <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                    <p className="text-sm text-destructive">{error}</p>
                  </div>
                )}

                <Button type="submit" className="w-full h-12 text-base font-semibold" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : step === "pin" ? (
                    "Verify PIN"
                  ) : step === "old-password" ? (
                    "Verify Old Password"
                  ) : (
                    "Update Password"
                  )}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
