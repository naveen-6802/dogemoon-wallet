"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getAddressFromWIF, validateDogecoinAddress } from "@/lib/dogecoin/crypto"
import { Loader2, AlertCircle, CheckCircle } from "lucide-react"

export default function SweepWalletPage() {
  const [wifKey, setWifKey] = useState("")
  const [destinationAddress, setDestinationAddress] = useState("")
  const [balance, setBalance] = useState<number | null>(null)
  const [sourceAddress, setSourceAddress] = useState<string | null>(null)
  const [step, setStep] = useState<"input" | "review" | "sent">("input")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [txHash, setTxHash] = useState<string | null>(null)
  const router = useRouter()

  const handleCheckBalance = async () => {
    setError(null)
    setIsLoading(true)

    try {
      // Validate WIF and get address
      const address = getAddressFromWIF(wifKey.trim())
      setSourceAddress(address)

      const response = await fetch("/api/check-balance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address }),
      })

      if (!response.ok) throw new Error("Failed to fetch balance")

      const data = await response.json()
      if (data.success) {
        setBalance(data.balance)

        if (data.balance > 0) {
          setStep("review")
        } else {
          setError("No Dogecoin balance found in this wallet")
        }
      } else {
        throw new Error(data.error || "Failed to fetch balance")
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to validate WIF or fetch balance")
      setSourceAddress(null)
      setBalance(null)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSweepWallet = async () => {
    setError(null)

    if (!validateDogecoinAddress(destinationAddress.trim())) {
      setError("Invalid destination Dogecoin address")
      return
    }

    if ((balance || 0) <= 0) {
      setError("No balance to sweep")
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/sweep-wallet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          from_address: sourceAddress,
          to_address: destinationAddress,
          private_key: wifKey.trim(),
        }),
      })

      if (!response.ok) throw new Error("Failed to broadcast transaction")

      const result = await response.json()
      if (result.success) {
        setTxHash(result.txid)
        setStep("sent")
      } else {
        throw new Error(result.error || "Transaction broadcast failed")
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to sweep wallet")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {step === "input" && (
        <Card>
          <CardHeader>
            <CardTitle>Import & Sweep Wallet</CardTitle>
            <CardDescription>Enter the WIF private key to sweep all funds to your DogeMoon wallet</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="wif">WIF Private Key</Label>
              <Input
                id="wif"
                type="password"
                placeholder="Enter WIF private key"
                value={wifKey}
                onChange={(e) => setWifKey(e.target.value)}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">Never share your private key with anyone</p>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-destructive" />
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <Button onClick={handleCheckBalance} disabled={!wifKey || isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Checking Balance...
                </>
              ) : (
                "Check Balance"
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {step === "review" && (
        <Card>
          <CardHeader>
            <CardTitle>Review Sweep</CardTitle>
            <CardDescription>Confirm the details before sweeping</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between p-3 bg-muted rounded">
                <span>Source Address:</span>
                <span className="font-mono text-sm">
                  {sourceAddress?.slice(0, 10)}...{sourceAddress?.slice(-10)}
                </span>
              </div>
              <div className="flex justify-between p-3 bg-muted rounded">
                <span>Balance:</span>
                <span className="font-semibold">{balance} DOGE</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="destination">Destination Address</Label>
              <Input
                id="destination"
                placeholder="Enter your DogeMoon receiving address"
                value={destinationAddress}
                onChange={(e) => setDestinationAddress(e.target.value)}
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-destructive" />
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep("input")} disabled={isLoading}>
                Back
              </Button>
              <Button onClick={handleSweepWallet} disabled={!destinationAddress || isLoading} className="flex-1">
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sweeping...
                  </>
                ) : (
                  "Sweep Now"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === "sent" && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-success">
              <CheckCircle className="w-5 h-5" />
              Sweep Complete
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">Your funds have been successfully swept to your DogeMoon wallet.</p>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Transaction Hash:</p>
              <div className="p-3 bg-muted rounded font-mono text-xs break-all">{txHash}</div>
            </div>
            <Button onClick={() => router.push("/wallet")} className="w-full">
              Back to Wallet
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
