"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { hashPin, verifyPin } from "@/lib/dogecoin/crypto"
import { DogeLogo } from "@/components/doge-logo"
import { PinPad } from "@/components/pin-pad"
import { ArrowLeft, Check } from "lucide-react"

type Step = "current" | "new" | "confirm" | "success"

export default function ChangePinPage() {
  const [step, setStep] = useState<Step>("current")
  const [currentPin, setCurrentPin] = useState("")
  const [newPin, setNewPin] = useState("")
  const [confirmPin, setConfirmPin] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const router = useRouter()

  const handlePinInput = async (digit: string) => {
    if (isProcessing) return

    if (digit === "delete") {
      if (step === "current") setCurrentPin((prev) => prev.slice(0, -1))
      else if (step === "new") setNewPin((prev) => prev.slice(0, -1))
      else if (step === "confirm") setConfirmPin((prev) => prev.slice(0, -1))
      setError(null)
      return
    }

    if (step === "current") {
      const pin = currentPin + digit
      setCurrentPin(pin)
      setError(null)

      if (pin.length === 6) {
        setIsProcessing(true)
        const supabase = createClient()
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (user) {
          const { data: profile } = await supabase.from("profiles").select("pin_hash").eq("id", user.id).single()

          if (profile?.pin_hash) {
            const isValid = await verifyPin(pin, profile.pin_hash)
            if (isValid) {
              setStep("new")
            } else {
              setError("Incorrect PIN")
              setCurrentPin("")
            }
          }
        }
        setIsProcessing(false)
      }
    } else if (step === "new") {
      const pin = newPin + digit
      setNewPin(pin)

      if (pin.length === 6) {
        setStep("confirm")
      }
    } else if (step === "confirm") {
      const pin = confirmPin + digit
      setConfirmPin(pin)
      setError(null)

      if (pin.length === 6) {
        if (pin === newPin) {
          setIsProcessing(true)
          const supabase = createClient()
          const {
            data: { user },
          } = await supabase.auth.getUser()

          if (user) {
            const pinHash = await hashPin(newPin)
            await supabase.from("profiles").update({ pin_hash: pinHash }).eq("id", user.id)
          }

          setStep("success")
          setIsProcessing(false)
        } else {
          setError("PINs do not match")
          setNewPin("")
          setConfirmPin("")
          setStep("new")
        }
      }
    }
  }

  const getCurrentPin = () => {
    if (step === "current") return currentPin
    if (step === "new") return newPin
    return confirmPin
  }

  if (step === "success") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mb-6">
          <Check className="w-10 h-10 text-success" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-2">PIN Changed!</h1>
        <p className="text-muted-foreground text-center mb-8">Your PIN has been updated successfully.</p>
        <Link href="/wallet/settings" className="text-primary hover:underline font-medium">
          Back to Settings
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="flex items-center p-4">
        <Link
          href="/wallet/settings"
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </Link>
      </header>

      <main className="flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-sm space-y-8">
          {/* Title */}
          <div className="text-center space-y-2">
            <DogeLogo className="w-16 h-16 mx-auto" />
            <h1 className="text-2xl font-bold text-foreground">
              {step === "current" && "Enter Current PIN"}
              {step === "new" && "Create New PIN"}
              {step === "confirm" && "Confirm New PIN"}
            </h1>
            <p className="text-muted-foreground text-sm">
              {step === "current" && "Enter your current 6-digit PIN"}
              {step === "new" && "Enter a new 6-digit PIN"}
              {step === "confirm" && "Enter your new PIN again"}
            </p>
          </div>

          {/* PIN Dots */}
          <div className="flex justify-center gap-3">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  i < getCurrentPin().length ? "bg-primary scale-110" : "bg-muted border-2 border-border"
                }`}
              />
            ))}
          </div>

          {/* Error */}
          {error && (
            <div className="text-center">
              <p className="text-destructive text-sm font-medium">{error}</p>
            </div>
          )}

          {/* PIN Pad */}
          <PinPad onInput={handlePinInput} disabled={isProcessing} />
        </div>
      </main>
    </div>
  )
}
