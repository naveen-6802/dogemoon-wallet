"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { validateDogecoinAddress } from "@/lib/dogecoin/crypto"
import { getWalletBalance, getDogecoinPrice, createTransaction, broadcastTransaction } from "@/lib/dogecoin/api"
import { signTransaction } from "@/lib/dogecoin/transaction-signer"
import { DogeLogo } from "@/components/doge-logo"
import { UnlockWalletModal } from "@/components/unlock-wallet-modal"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { QrScanner } from "@/components/qr-scanner"
import { ArrowRight, Scan, AlertCircle, Loader2, Check, ExternalLink, Lock } from "lucide-react"
import { useSearchParams } from "next/navigation"
import { PinPad } from "@/components/pin-pad"

type Step = "input" | "pin" | "confirm" | "sending" | "success" | "error"

export default function SendPage() {
  const { wallet, mnemonic, setWalletAddress, refreshBalance } = useWallet()
  const searchParams = useSearchParams()
  const [step, setStep] = useState<Step>("input")
  const [address, setAddress] = useState("")
  const [amount, setAmount] = useState("")
  const [balance, setBalance] = useState(0)
  const [dogePrice, setDogePrice] = useState(0)
  const [showScanner, setShowScanner] = useState(false)
  const [showUnlockModal, setShowUnlockModal] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [txHash, setTxHash] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [estimatedFee] = useState(0.01) // Changed estimated fee from 1 to 0.01
  const router = useRouter()
  const inputRef = useRef<HTMLInputElement>(null)
  const [pin, setPin] = useState("")

  useEffect(() => {
    loadWalletData()
    if (searchParams.get("scan") === "true") {
      setShowScanner(true)
    }
  }, [searchParams])

  const loadWalletData = async () => {
    const sessionAddress = sessionStorage.getItem("dogemoon_address")
    if (sessionAddress) {
      setWalletAddress(sessionAddress)
      await fetchBalance(sessionAddress)
      return
    }

    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/auth/login")
      return
    }

    const { data: profile } = await supabase.from("profiles").select("wallet_address").eq("id", user.id).single()

    if (profile?.wallet_address) {
      setWalletAddress(profile.wallet_address)
      await fetchBalance(profile.wallet_address)
    } else {
      setIsLoading(false)
    }
  }

  const fetchBalance = async (addr: string) => {
    try {
      const [balanceData, price] = await Promise.all([getWalletBalance(addr), getDogecoinPrice()])
      setBalance(balanceData.balance)
      setDogePrice(price)
    } catch (err) {
      console.error("Failed to fetch balance:", err)
    }
    setIsLoading(false)
  }

  const handleScan = (result: string) => {
    setShowScanner(false)

    if (result.startsWith("dogecoin:")) {
      const [addr, params] = result.slice(9).split("?")
      setAddress(addr)

      if (params) {
        const searchParams = new URLSearchParams(params)
        const amt = searchParams.get("amount")
        if (amt) setAmount(amt)
      }
    } else {
      setAddress(result)
    }
  }

  const validateInput = (): string | null => {
    if (!address.trim()) {
      return "Please enter a recipient address"
    }

    if (!validateDogecoinAddress(address.trim())) {
      return "Invalid Dogecoin address"
    }

    if (!amount || Number.parseFloat(amount) <= 0) {
      return "Please enter an amount"
    }

    if (Number.parseFloat(amount) < 0.01) {
      // Updated minimum amount to 0.01
      return "Minimum amount is 0.01 DOGE"
    }

    if (Number.parseFloat(amount) + estimatedFee > balance) {
      return `Insufficient balance (need ~${estimatedFee} DOGE for fee)`
    }

    return null
  }

  const handleReview = () => {
    const validationError = validateInput()
    if (validationError) {
      setError(validationError)
      return
    }

    setError(null)
    setStep("pin")
  }

  const handlePinInput = async (digit: string) => {
    if (digit === "delete") {
      setPin((prev) => prev.slice(0, -1))
      return
    }
    const newPin = pin + digit
    setPin(newPin)
    if (newPin.length === 6) {
      setIsLoading(true)
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (user) {
        const { data: profile } = await supabase.from("profiles").select("pin_hash").eq("id", user.id).single()
        const { verifyPin } = await import("@/lib/dogecoin/crypto")
        const isValid = await verifyPin(newPin, profile?.pin_hash || "")
        if (isValid) {
          setStep("confirm")
        } else {
          setError("Incorrect PIN")
          setPin("")
        }
      }
      setIsLoading(false)
    }
  }

  const handleSend = async () => {
    setStep("sending")
    setError(null)

    try {
      if (!mnemonic) {
        throw new Error("Wallet not unlocked. Please unlock your wallet first. Go to Settings > Backup Wallet > Click on Import Wallet > Enter Your Recovery Phrase > Import wallet. This is due to security purpose, whenever you sign out and sign in into new device/new session, it always asks your seed phrase because we do not store it on our servers.")
      }

      if (!wallet.address) {
        throw new Error("No wallet address found")
      }

      console.log("[v0] Creating transaction:", {
        from: wallet.address,
        to: address.trim(),
        amount: Number.parseFloat(amount),
      })

      // Create transaction
      const txSkeleton = await createTransaction(wallet.address, address.trim(), Number.parseFloat(amount))

      console.log("[v0] Transaction skeleton received:", {
        tosignCount: txSkeleton.tosign?.length,
        tx: txSkeleton.tx?.hash,
      })

      if (!txSkeleton.tosign || txSkeleton.tosign.length === 0) {
        throw new Error("No transaction to sign - insufficient UTXOs or invalid transaction")
      }

      // Sign transaction
      console.log("[v0] Signing transaction...")
      const { signatures, publicKey } = await signTransaction(mnemonic, txSkeleton.tosign)

      console.log("[v0] Signatures created:", signatures.length)

      // Broadcast transaction
      console.log("[v0] Broadcasting transaction...")
      const result = await broadcastTransaction(txSkeleton, signatures, [publicKey])

      console.log("[v0] Transaction broadcast success:", result.hash)
      setTxHash(result.hash)
      setStep("success")
      refreshBalance()
    } catch (err) {
      console.error("[v0] Transaction failed:", err)
      const errorMessage = err instanceof Error ? err.message : "Transaction failed. Please try again."
      setError(errorMessage)
      setStep("error")
    }
  }

  const handleSetMax = () => {
    const maxAmount = Math.max(0, balance - estimatedFee)
    setAmount(maxAmount.toFixed(8))
  }

  const usdValue = amount ? (Number.parseFloat(amount) * dogePrice).toFixed(2) : "0.00"

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <DogeLogo className="w-12 h-12 animate-pulse" />
      </div>
    )
  }

  if (showScanner) {
    return (
      <div className="min-h-screen bg-background">
        <QrScanner onScan={handleScan} onClose={() => setShowScanner(false)} />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <UnlockWalletModal
        open={showUnlockModal}
        onOpenChange={setShowUnlockModal}
        onUnlock={() => {
          setError(null)
          setStep("confirm")
        }}
      />

      <header className="p-4 lg:p-6 lg:border-b lg:border-border max-w-md mx-auto w-full">
        <h1 className="text-xl lg:text-2xl font-bold text-foreground text-center lg:text-left">
          {step === "input" && "Send DOGE"}
          {step === "pin" && "Enter PIN"}
          {step === "confirm" && "Confirm Transaction"}
          {step === "sending" && "Sending..."}
          {step === "success" && "Transaction Sent!"}
          {step === "error" && "Transaction Failed"}
        </h1>
      </header>

      <main className="px-4 pb-24 lg:px-6 lg:pb-6 max-w-md mx-auto w-full">
        {/* Input Step */}
        {step === "input" && (
          <div className="space-y-6 mt-6 lg:mt-10">
            {!mnemonic && (
              <Card className="p-3 bg-primary/5 border-primary/20">
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-primary shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Wallet Locked</p>
                    <p className="text-xs text-muted-foreground">
                      You'll need to unlock with your recovery phrase to send
                    </p>
                  </div>
                </div>
              </Card>
            )}

            <Card className="p-4 text-center">
              <p className="text-sm text-muted-foreground mb-1">Available Balance</p>
              <p className="text-2xl font-bold text-foreground">
                {balance.toLocaleString(undefined, { maximumFractionDigits: 8 })} DOGE
              </p>
            </Card>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Recipient Address</label>
              <div className="flex gap-2">
                <Input
                  ref={inputRef}
                  type="text"
                  placeholder="D..."
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value)
                    setError(null)
                  }}
                  className="h-12 font-mono text-sm"
                />
                <Button
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 shrink-0 bg-transparent"
                  onClick={() => setShowScanner(true)}
                >
                  <Scan className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground">Amount</label>
                <button onClick={handleSetMax} className="text-sm text-primary hover:underline">
                  Max
                </button>
              </div>
              <div className="relative">
                <Input
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => {
                    setAmount(e.target.value)
                    setError(null)
                  }}
                  className="h-14 text-2xl font-bold pr-20"
                  step="0.00000001"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground font-semibold">
                  DOGE
                </span>
              </div>
              <p className="text-sm text-muted-foreground">≈ ${usdValue} USD</p>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-destructive bg-destructive/10 p-3 rounded-lg">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <p className="text-sm">{error}</p>
              </div>
            )}

            <Button onClick={handleReview} className="w-full h-12 text-base font-semibold">
              {mnemonic ? "Review Transaction" : "Unlock & Review"}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        )}

        {/* PIN Step */}
        {step === "pin" && (
          <div className="space-y-8 mt-6 lg:mt-10 text-center">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Enter PIN</h2>
              <p className="text-muted-foreground text-sm">Enter your 6-digit PIN to authorize payment</p>
            </div>
            <div className="flex justify-center gap-3">
              {[...Array(6)].map((_, i) => (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-full transition-all duration-200 ${
                    i < pin.length ? "bg-primary scale-110" : "bg-muted border-2 border-border"
                  }`}
                />
              ))}
            </div>
            {error && <p className="text-destructive text-sm font-medium">{error}</p>}
            <div className="pt-4">
              <PinPad onInput={handlePinInput} />
            </div>
            <Button variant="ghost" onClick={() => setStep("input")} className="w-full">
              Cancel
            </Button>
          </div>
        )}

        {/* Confirm Step */}
        {step === "confirm" && (
          <div className="space-y-6 mt-6 lg:mt-10">
            <Card className="p-6 space-y-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Sending</p>
                <p className="text-3xl font-bold text-foreground">
                  {Number.parseFloat(amount).toLocaleString(undefined, { maximumFractionDigits: 8 })} DOGE
                </p>
                <p className="text-sm text-muted-foreground">≈ ${usdValue} USD</p>
              </div>

              <div className="h-px bg-border" />

              <div>
                <p className="text-sm text-muted-foreground mb-1">To</p>
                <p className="font-mono text-sm text-foreground break-all">{address}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-1">Estimated Network Fee</p>
                <p className="font-medium text-foreground">~{estimatedFee} DOGE</p>{" "}
                {/* Updated fee display to show 0.01 */}
              </div>
            </Card>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep("pin")} className="flex-1 h-12 bg-transparent">
                Back
              </Button>
              <Button onClick={handleSend} className="flex-1 h-12 font-semibold">
                Confirm & Send
              </Button>
            </div>
          </div>
        )}

        {/* Sending Step */}
        {step === "sending" && (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="w-16 h-16 text-primary animate-spin mb-6" />
            <p className="text-lg font-semibold text-foreground">Processing Transaction</p>
            <p className="text-sm text-muted-foreground">Please wait...</p>
          </div>
        )}

        {/* Success Step */}
        {step === "success" && (
          <div className="space-y-6 mt-6 lg:mt-10">
            <div className="flex flex-col items-center py-8">
              <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
                <Check className="w-10 h-10 text-green-500" />
              </div>
              <h2 className="text-xl font-bold text-foreground mb-1">Transaction Sent!</h2>
              <p className="text-muted-foreground text-center">
                Your transaction has been sent via Dogecoin network.
              </p>
            </div>
            <Card className="p-4">
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Amount</p>
                  <p className="font-semibold text-foreground">
                    {Number.parseFloat(amount).toLocaleString(undefined, { maximumFractionDigits: 8 })} DOGE
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Transaction Hash</p>
                  <p className="font-mono text-xs text-foreground break-all">{txHash}</p>
                </div>
              </div>
            </Card>
            {txHash && (
              <a
                href={`https://dogechain.info/tx/${txHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 text-primary hover:underline"
              >
                View on Explorer
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
            <Button onClick={() => router.push("/wallet")} className="w-full h-12 font-semibold">
              Back to Wallet
            </Button>
          </div>
        )}

        {/* Error Step */}
        {step === "error" && (
          <div className="space-y-6 mt-6 lg:mt-10">
            <div className="flex flex-col items-center py-8">
              <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
                <AlertCircle className="w-10 h-10 text-destructive" />
              </div>
              <h2 className="text-xl font-bold text-foreground mb-1">Transaction Failed</h2>
              <p className="text-muted-foreground text-center max-w-xs">
                {error || "Something went wrong. Please try again."}
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => router.push("/wallet")} className="flex-1 h-12 bg-transparent">
                Cancel
              </Button>
              <Button onClick={() => setStep("input")} className="flex-1 h-12 font-semibold">
                Try Again
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
