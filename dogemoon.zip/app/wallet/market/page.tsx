"use client"

import { useState, useEffect, useCallback } from "react"
import { DogeLogo } from "@/components/doge-logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { formatNumber, formatCurrency, formatLargeNumber } from "@/lib/utils"
import { TrendingUp, TrendingDown, RefreshCw, ExternalLink, BarChart3, Activity, Clock } from "lucide-react"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"

interface MarketData {
  price: number
  priceChange24h: number
  priceChangePercentage24h: number
  marketCap: number
  volume24h: number
  high24h: number
  low24h: number
  circulatingSupply: number
  totalSupply: number
  ath: number
  athDate: string
  athChangePercentage: number
}

interface ChartData {
  timestamp: number
  price: number
  date: string
}

type TimeRange = "1D" | "7D" | "30D" | "90D" | "1Y"

export default function MarketPage() {
  const [marketData, setMarketData] = useState<MarketData | null>(null)
  const [chartData, setChartData] = useState<ChartData[]>([])
  const [timeRange, setTimeRange] = useState<TimeRange>("7D")
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null)

  const timeRanges: { label: TimeRange; days: number }[] = [
    { label: "1D", days: 1 },
    { label: "7D", days: 7 },
    { label: "30D", days: 30 },
    { label: "90D", days: 90 },
    { label: "1Y", days: 365 },
  ]

  const fetchMarketData = useCallback(async () => {
    try {
      const response = await fetch(
        "https://api.coingecko.com/api/v3/coins/dogecoin?localization=false&tickers=false&community_data=false&developer_data=false",
      )

      if (!response.ok) throw new Error("Failed to fetch market data")

      const data = await response.json()

      setMarketData({
        price: data.market_data.current_price.usd,
        priceChange24h: data.market_data.price_change_24h,
        priceChangePercentage24h: data.market_data.price_change_percentage_24h,
        marketCap: data.market_data.market_cap.usd,
        volume24h: data.market_data.total_volume.usd,
        high24h: data.market_data.high_24h.usd,
        low24h: data.market_data.low_24h.usd,
        circulatingSupply: data.market_data.circulating_supply,
        totalSupply: data.market_data.total_supply,
        ath: data.market_data.ath.usd,
        athDate: data.market_data.ath_date.usd,
        athChangePercentage: data.market_data.ath_change_percentage.usd,
      })

      setLastUpdated(new Date())
    } catch (error) {
      console.error("Failed to fetch market data:", error)
    }
  }, [])

  const fetchChartData = useCallback(async (days: number) => {
    try {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/dogecoin/market_chart?vs_currency=usd&days=${days}`,
      )

      if (!response.ok) throw new Error("Failed to fetch chart data")

      const data = await response.json()

      const formattedData: ChartData[] = data.prices.map((item: [number, number]) => ({
        timestamp: item[0],
        price: item[1],
        date: new Date(item[0]).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          hour: days <= 1 ? "numeric" : undefined,
        }),
      }))

      const interval = Math.ceil(formattedData.length / 50)
      const reducedData = formattedData.filter((_, index) => index % interval === 0)

      setChartData(reducedData)
    } catch (error) {
      console.error("Failed to fetch chart data:", error)
    }
  }, [])

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      await Promise.all([fetchMarketData(), fetchChartData(getDaysFromRange(timeRange))])
      setIsLoading(false)
    }

    loadData()
  }, [fetchMarketData, fetchChartData, timeRange])

  const getDaysFromRange = (range: TimeRange): number => {
    const found = timeRanges.find((r) => r.label === range)
    return found?.days || 7
  }

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await Promise.all([fetchMarketData(), fetchChartData(getDaysFromRange(timeRange))])
    setIsRefreshing(false)
  }

  const handleTimeRangeChange = async (range: TimeRange) => {
    setTimeRange(range)
    await fetchChartData(getDaysFromRange(range))
  }

  const isPositive = marketData ? marketData.priceChangePercentage24h >= 0 : true
  const chartColor = isPositive ? "#22c55e" : "#ef4444"

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <RefreshCw className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-24 lg:pb-6">
      {/* Header - Mobile only */}
      <header className="flex items-center justify-between p-4 lg:hidden">
        <div className="flex items-center gap-2">
          <DogeLogo className="w-8 h-8" />
          <span className="font-semibold text-foreground">Market</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="rounded-full" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
          <ThemeToggle />
        </div>
      </header>

      {/* Desktop Header */}
      <header className="hidden lg:flex items-center justify-between p-6 border-b border-border">
        <h1 className="text-2xl font-bold text-foreground">Market</h1>
        <Button variant="ghost" size="icon" className="rounded-full" onClick={handleRefresh} disabled={isRefreshing}>
          <RefreshCw className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} />
        </Button>
      </header>

      <main className="px-4 lg:px-6 space-y-4 lg:grid lg:grid-cols-3 lg:gap-6 lg:space-y-0 lg:pt-6">
        {/* Price Card - 2 columns on desktop */}
        <Card className="p-6 lg:col-span-2">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <DogeLogo className="w-12 h-12" />
              <div>
                <h1 className="text-xl font-bold text-foreground">Dogecoin</h1>
                <p className="text-sm text-muted-foreground">DOGE</p>
              </div>
            </div>
            <a
              href="https://www.coingecko.com/en/coins/dogecoin"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ExternalLink className="w-5 h-5" />
            </a>
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline gap-3">
              <span className="text-4xl lg:text-5xl font-bold text-foreground">${marketData?.price.toFixed(6)}</span>
            </div>
            <div className="flex items-center gap-2">
              <div
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm font-medium ${
                  isPositive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                }`}
              >
                {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{Math.abs(marketData?.priceChangePercentage24h || 0).toFixed(2)}%</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {isPositive ? "+" : ""}
                {marketData?.priceChange24h.toFixed(6)} (24h)
              </span>
            </div>
          </div>
        </Card>

        {/* Stats Grid - 1 column on desktop right side */}
        <div className="space-y-3 lg:space-y-4">
          <Card className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <BarChart3 className="w-4 h-4" />
              <span className="text-xs">Market Cap</span>
            </div>
            <p className="font-semibold text-foreground text-lg">{formatCurrency(marketData?.marketCap || 0)}</p>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Activity className="w-4 h-4" />
              <span className="text-xs">24h Volume</span>
            </div>
            <p className="font-semibold text-foreground text-lg">{formatCurrency(marketData?.volume24h || 0)}</p>
          </Card>

          <div className="grid grid-cols-2 gap-3">
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <TrendingUp className="w-4 h-4" />
                <span className="text-xs">24h High</span>
              </div>
              <p className="font-semibold text-green-500">${marketData?.high24h.toFixed(6)}</p>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <TrendingDown className="w-4 h-4" />
                <span className="text-xs">24h Low</span>
              </div>
              <p className="font-semibold text-red-500">${marketData?.low24h.toFixed(6)}</p>
            </Card>
          </div>
        </div>

        {/* Chart - full width */}
        <Card className="p-4 lg:col-span-3">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-foreground">Price Chart</h2>
            <div className="flex gap-1">
              {timeRanges.map((range) => (
                <button
                  key={range.label}
                  onClick={() => handleTimeRangeChange(range.label)}
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeRange === range.label
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  }`}
                >
                  {range.label}
                </button>
              ))}
            </div>
          </div>

          <div className="h-64 lg:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={chartColor} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={chartColor} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  domain={["auto", "auto"]}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `$${value.toFixed(4)}`}
                  width={70}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    color: "hsl(var(--foreground))",
                  }}
                  formatter={(value: number) => [`$${value.toFixed(6)}`, "Price"]}
                  labelStyle={{ color: "hsl(var(--muted-foreground))" }}
                />
                <Area
                  type="monotone"
                  dataKey="price"
                  stroke={chartColor}
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorPrice)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* More Stats - full width */}
        <Card className="p-4 lg:col-span-3 space-y-4">
          <h2 className="font-semibold text-foreground">Market Statistics</h2>

          <div className="lg:grid lg:grid-cols-2 lg:gap-x-8 space-y-3 lg:space-y-0">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">Circulating Supply</span>
              <span className="font-medium text-foreground">
                {formatLargeNumber(marketData?.circulatingSupply || 0)} DOGE
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">Total Supply</span>
              <span className="font-medium text-foreground">
                {marketData?.totalSupply ? formatLargeNumber(marketData.totalSupply) + " DOGE" : "Unlimited"}
              </span>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">All-Time High</span>
              <div className="text-right">
                <p className="font-medium text-foreground">${marketData?.ath.toFixed(4)}</p>
                <p className="text-xs text-red-500">
                  {formatNumber(marketData?.athChangePercentage || 0, 2)}% from ATH
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-border lg:border-b-0">
              <span className="text-muted-foreground">ATH Date</span>
              <span className="font-medium text-foreground">
                {marketData?.athDate
                  ? new Date(marketData.athDate).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })
                  : "-"}
              </span>
            </div>
          </div>
        </Card>

        {/* Last Updated */}
        <div className="lg:col-span-3">
          {lastUpdated && (
            <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground mb-2">
              <Clock className="w-3 h-3" />
              <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
            </div>
          )}

          {/* Data Source */}
          <p className="text-center text-xs text-muted-foreground">
            Data provided by{" "}
            <a
              href="https://www.coingecko.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              CoinGecko
            </a>
          </p>
        </div>
      </main>
    </div>
  )
}
