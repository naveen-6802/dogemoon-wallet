"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { BottomNav } from "@/components/bottom-nav"
import { SidebarNav } from "@/components/sidebar-nav"
import { Loader2 } from "lucide-react"

export default function WalletLayout({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const checkAuth = async () => {
      const supabase = createClient()
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push(`/auth/login?redirect=${encodeURIComponent(pathname)}`)
        return
      }

      setIsLoading(false)
    }

    checkAuth()
  }, [router, pathname])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <SidebarNav />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen lg:max-h-screen lg:overflow-auto">
        <main className="flex-1 pb-20 lg:pb-6 flex flex-col items-center">
          <div className="w-full max-w-6xl">{children}</div>
        </main>
        {/* Mobile Bottom Nav */}
        <BottomNav />
      </div>
    </div>
  )
}
