"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { generateMnemonic, deriveWalletFromMnemonic } from "@/lib/dogecoin/crypto"
import { DogeLogo } from "@/components/doge-logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Copy, Check, AlertTriangle, Eye, EyeOff, Loader2 } from "lucide-react"
import Link from "next/link"

type Step = "generate" | "backup" | "verify"

export default function CreateWalletPage() {
  const [step, setStep] = useState<Step>("generate")
  const [mnemonic, setMnemonic] = useState<string>("")
  const [showMnemonic, setShowMnemonic] = useState(false)
  const [copied, setCopied] = useState(false)
  const [acknowledged, setAcknowledged] = useState(false)
  const [verifyWords, setVerifyWords] = useState<{ index: number; word: string }[]>([])
  const [userInput, setUserInput] = useState<string[]>(["", "", ""])
  const [verifyError, setVerifyError] = useState<string | null>(null)
  const [isCreating, setIsCreating] = useState(false)
  const { setWalletAddress, setMnemonic: setContextMnemonic } = useWallet()
  const router = useRouter()

  const handleGenerateMnemonic = () => {
    const newMnemonic = generateMnemonic()
    setMnemonic(newMnemonic)
    setContextMnemonic(newMnemonic) // Store mnemonic in context

    // Select 3 random words for verification
    const words = newMnemonic.split(" ")
    const indices = [2, 5, 9] // Words 3, 6, 10 (0-indexed)
    setVerifyWords(indices.map((i) => ({ index: i, word: words[i] })))

    setStep("backup")
  }

  const copyMnemonic = () => {
    navigator.clipboard.writeText(mnemonic)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleProceedToVerify = () => {
    if (!acknowledged) return
    setStep("verify")
  }

  const handleVerify = async () => {
    const isCorrect = verifyWords.every((vw, i) => userInput[i].toLowerCase().trim() === vw.word.toLowerCase())

    if (!isCorrect) {
      setVerifyError("Incorrect words. Please check your backup and try again.")
      return
    }

    setIsCreating(true)

    try {
      // Derive wallet from mnemonic
      const walletData = await deriveWalletFromMnemonic(mnemonic)

      setContextMnemonic(mnemonic)
      sessionStorage.setItem("dogemoon_address", walletData.address)

      // Update database
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (user) {
        await supabase
          .from("profiles")
          .update({ has_wallet: true, wallet_address: walletData.address })
          .eq("id", user.id)
      }

      setWalletAddress(walletData.address)
      router.push("/wallet")
    } catch (error) {
      setVerifyError("Failed to create wallet. Please try again.")
    } finally {
      setIsCreating(false)
    }
  }

  const words = mnemonic.split(" ")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="flex items-center justify-between p-4">
        <Link
          href="/wallet"
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </Link>
        <ThemeToggle />
      </header>

      <main className="px-4 pb-8">
        {step === "generate" && (
          <div className="max-w-md mx-auto space-y-6">
            <div className="text-center space-y-2">
              <DogeLogo className="w-20 h-20 mx-auto" />
              <h1 className="text-2xl font-bold text-foreground">Create New Wallet</h1>
              <p className="text-muted-foreground">Generate a new secure wallet with a 12-word recovery phrase.</p>
            </div>

            <Card className="p-4 bg-primary/5 border-primary/20">
              <div className="flex gap-3">
                <AlertTriangle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-foreground mb-1">Important Security Notice</p>
                  <p className="text-muted-foreground">
                    Your recovery phrase is the ONLY way to restore your wallet. Write it down and store it securely.
                    Never share it with anyone.
                  </p>
                </div>
              </div>
            </Card>

            <Button onClick={handleGenerateMnemonic} className="w-full h-12 text-base font-semibold">
              Generate Recovery Phrase
            </Button>
          </div>
        )}

        {step === "backup" && (
          <div className="max-w-md mx-auto space-y-6">
            <div className="text-center space-y-2">
              <h1 className="text-2xl font-bold text-foreground">Backup Recovery Phrase</h1>
              <p className="text-muted-foreground">Write down these 12 words in order and store them safely.</p>
            </div>

            {/* Mnemonic Display */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-medium text-muted-foreground">Your Recovery Phrase</span>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setShowMnemonic(!showMnemonic)}>
                    {showMnemonic ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={copyMnemonic}>
                    {copied ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {words.map((word, index) => (
                  <div key={index} className="bg-muted rounded-lg p-2 text-center">
                    <span className="text-xs text-muted-foreground">{index + 1}.</span>{" "}
                    <span className={`font-mono ${showMnemonic ? "" : "blur-sm select-none"}`}>{word}</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Warning */}
            <Card className="p-4 bg-destructive/5 border-destructive/20">
              <div className="flex gap-3">
                <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-foreground mb-1">Never Share Your Recovery Phrase</p>
                  <ul className="text-muted-foreground space-y-1">
                    <li>- DogeMoon will NEVER ask for your recovery phrase</li>
                    <li>- Anyone with these words can access your funds</li>
                    <li>- Store offline in a secure location</li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* Acknowledgment */}
            <div className="flex items-start gap-3">
              <Checkbox
                id="acknowledge"
                checked={acknowledged}
                onCheckedChange={(checked) => setAcknowledged(checked as boolean)}
                className="mt-0.5"
              />
              <label htmlFor="acknowledge" className="text-sm text-muted-foreground cursor-pointer">
                I have written down my recovery phrase and understand that losing it means losing access to my wallet
                forever.
              </label>
            </div>

            <Button
              onClick={handleProceedToVerify}
              disabled={!acknowledged}
              className="w-full h-12 text-base font-semibold"
            >
              Continue to Verification
            </Button>
          </div>
        )}

        {step === "verify" && (
          <div className="max-w-md mx-auto space-y-6">
            <div className="text-center space-y-2">
              <h1 className="text-2xl font-bold text-foreground">Verify Recovery Phrase</h1>
              <p className="text-muted-foreground">
                Enter the requested words to confirm you&apos;ve backed up your phrase.
              </p>
            </div>

            <div className="space-y-4">
              {verifyWords.map((vw, i) => (
                <div key={vw.index} className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Word #{vw.index + 1}</label>
                  <input
                    type="text"
                    value={userInput[i]}
                    onChange={(e) => {
                      const newInput = [...userInput]
                      newInput[i] = e.target.value
                      setUserInput(newInput)
                      setVerifyError(null)
                    }}
                    className="w-full h-12 px-4 rounded-lg bg-muted border border-input text-foreground font-mono focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder={`Enter word #${vw.index + 1}`}
                  />
                </div>
              ))}
            </div>

            {verifyError && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <p className="text-sm text-destructive">{verifyError}</p>
              </div>
            )}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep("backup")} className="flex-1 h-12 bg-transparent">
                Back
              </Button>
              <Button
                onClick={handleVerify}
                disabled={userInput.some((v) => !v.trim()) || isCreating}
                className="flex-1 h-12 font-semibold"
              >
                {isCreating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Wallet"
                )}
              </Button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
