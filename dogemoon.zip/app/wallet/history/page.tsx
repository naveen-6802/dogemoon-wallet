"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useWallet } from "@/contexts/wallet-context"
import { getTransactionHistory, type Transaction } from "@/lib/dogecoin/api"
import { DogeLogo } from "@/components/doge-logo"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowUpRight, ArrowDownLeft, RefreshCw, ExternalLink, Clock } from "lucide-react"
import { formatNumber } from "@/lib/utils"

export default function HistoryPage() {
  const { wallet, setWalletAddress } = useWallet()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const router = useRouter()

  useEffect(() => {
    loadTransactions()
  }, [])

  const loadTransactions = async () => {
    let address = sessionStorage.getItem("dogemoon_address")

    if (!address) {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data: profile } = await supabase.from("profiles").select("wallet_address").eq("id", user.id).single()

      address = profile?.wallet_address || null
    }

    if (address) {
      setWalletAddress(address)
      await fetchTransactions(address)
    }

    setIsLoading(false)
  }

  const fetchTransactions = async (address: string) => {
    try {
      const txs = await getTransactionHistory(address)
      setTransactions(txs)
    } catch (error) {
      console.error("Failed to fetch transactions:", error)
    }
  }

  const handleRefresh = async () => {
    if (!wallet.address || isRefreshing) return
    setIsRefreshing(true)
    await fetchTransactions(wallet.address)
    setIsRefreshing(false)
  }

  const truncateAddress = (address: string) => {
    if (!address) return "Unknown"
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  const formatDate = (timestamp: string) => {
    if (!timestamp) return "Pending"
    const date = new Date(timestamp)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <DogeLogo className="w-12 h-12 animate-pulse" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="flex items-center justify-between p-4 lg:p-6 lg:border-b lg:border-border max-w-4xl mx-auto w-full">
        <h1 className="text-xl lg:text-2xl font-bold text-foreground">Transaction History</h1>
        <Button variant="ghost" size="icon" className="rounded-full" onClick={handleRefresh} disabled={isRefreshing}>
          <RefreshCw className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} />
        </Button>
      </header>

      <main className="px-4 pb-24 lg:px-6 lg:pb-6 lg:mt-8 max-w-4xl mx-auto w-full overflow-x-hidden">
        {transactions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Clock className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-lg font-semibold text-foreground mb-1">No Transactions Yet</h2>
            <p className="text-sm text-muted-foreground max-w-xs">
              Your transaction history will appear here once you send or receive DOGE.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {transactions.map((tx) => (
              <Card key={tx.hash} className="p-4 overflow-hidden">
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                      tx.type === "received" ? "bg-success/10" : "bg-primary/10"
                    }`}
                  >
                    {tx.type === "received" ? (
                      <ArrowDownLeft className="w-5 h-5 text-success" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-primary" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0 overflow-hidden">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <p className="font-semibold text-foreground">{tx.type === "received" ? "Received" : "Sent"}</p>
                      <p
                        className={`font-semibold text-sm sm:text-base shrink-0 ${tx.type === "received" ? "text-success" : "text-foreground"}`}
                      >
                        {tx.type === "received" ? "+" : "-"}
                        {formatNumber(tx.amount, 2)} DOGE
                      </p>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs sm:text-sm text-muted-foreground truncate font-mono">
                        {tx.type === "received" ? "From: " : "To: "}
                        {truncateAddress(tx.address)}
                      </p>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full shrink-0 ${
                          tx.confirmations > 0 ? "bg-success/10 text-success" : "bg-primary/10 text-primary"
                        }`}
                      >
                        {tx.confirmations > 0 ? `${formatNumber(tx.confirmations, 0)} conf` : "Pending"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-border gap-2">
                      <p className="text-xs text-muted-foreground truncate">{formatDate(tx.timestamp)}</p>
                      <a
                        href={`https://dogechain.info/tx/${tx.hash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs text-primary hover:underline shrink-0"
                      >
                        View
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
