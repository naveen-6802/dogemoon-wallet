import Link from "next/link"
import { DogeLogo } from "@/components/doge-logo"
import { Card } from "@/components/ui/card"
import {
  ArrowLeft,
  Shield,
  Key,
  Zap,
  Heart,
  Wallet,
  Send,
  QrCode,
  Lock,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
} from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="flex items-center p-4 lg:p-6 lg:border-b lg:border-border">
        <Link
          href="/wallet/settings"
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </Link>
      </header>

      <main className="px-4 pb-8 max-w-2xl mx-auto lg:px-6 lg:mt-10">
        <div className="text-center mb-8">
          <DogeLogo className="w-24 h-24 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground">DogeMoon Wallet</h1>
          <p className="text-muted-foreground">Version 1.0.0</p>
        </div>

        <p className="text-center text-muted-foreground mb-8">
          DogeMoon is a self-custodial Dogecoin wallet that puts you in control of your crypto. Your keys, your coins.
        </p>

        {/* Quick Start Guide */}
        <Card className="p-6 mb-6 bg-primary/5 border-primary/20">
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            Quick Start Guide
          </h2>

          <div className="space-y-4">
            {/* Step 1 */}
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shrink-0">
                1
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <Wallet className="w-4 h-4" /> Create or Import Wallet
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Create a new wallet to get a fresh 12-word recovery phrase, or import an existing wallet using your
                  backup phrase.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shrink-0">
                2
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <Key className="w-4 h-4" /> Backup Your Recovery Phrase
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  <strong className="text-destructive">CRITICAL:</strong> Write down your 12-word phrase and store it
                  safely offline. This is the ONLY way to recover your wallet if you lose access.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shrink-0">
                3
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <ArrowDownLeft className="w-4 h-4" /> Receive DOGE
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Go to the <strong>Receive</strong> tab to see your wallet address and QR code. Share this with anyone
                  who wants to send you DOGE.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shrink-0">
                4
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <ArrowUpRight className="w-4 h-4" /> Send DOGE
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Go to the <strong>Send</strong> tab. Enter an address manually or scan a QR code. You&apos;ll need to
                  unlock your wallet with your recovery phrase to send.
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shrink-0">
                5
              </div>
              <div>
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <Lock className="w-4 h-4" /> Unlock Wallet for Transactions
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  When sending DOGE, you&apos;ll be asked to enter your recovery phrase. This is for security - we
                  don&apos;t store it, so you need to enter it each session.
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* How to Use Each Feature */}
        <h2 className="text-lg font-bold text-foreground mb-4">Features Guide</h2>

        <div className="space-y-4 mb-8">
          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <QrCode className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Scan to Pay</h3>
              <p className="text-sm text-muted-foreground">
                On the Send page, tap &quot;Scan QR&quot; to open your camera. Point it at any Dogecoin QR code to
                automatically fill the recipient address.
              </p>
            </div>
          </Card>

          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <RefreshCw className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Transaction History</h3>
              <p className="text-sm text-muted-foreground">
                View all your sent and received transactions in the History tab. Tap the refresh button to get the
                latest transactions. Click &quot;View&quot; to see details on the blockchain.
              </p>
            </div>
          </Card>

          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Send className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Transaction Fees</h3>
              <p className="text-sm text-muted-foreground">
                DogeMoon uses the minimum network fee (0.01 DOGE) to keep your costs low. Transactions typically confirm
                within a few minutes.
              </p>
            </div>
          </Card>
        </div>

        {/* Features */}
        <h2 className="text-lg font-bold text-foreground mb-4">Why DogeMoon?</h2>

        <div className="space-y-4">
          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Self-Custodial</h3>
              <p className="text-sm text-muted-foreground">
                Your private keys never leave your device. Only you have access to your funds. We can&apos;t freeze,
                access, or control your wallet.
              </p>
            </div>
          </Card>

          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Key className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Secure Backup</h3>
              <p className="text-sm text-muted-foreground">
                Your 12-word recovery phrase uses the industry-standard BIP39 format. You can restore your wallet on any
                compatible app.
              </p>
            </div>
          </Card>

          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Fast & Simple</h3>
              <p className="text-sm text-muted-foreground">
                Send and receive DOGE with just a few taps. Scan QR codes for quick transactions. No complex setup
                required.
              </p>
            </div>
          </Card>

          <Card className="p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Heart className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Community First</h3>
              <p className="text-sm text-muted-foreground">
                Built by the community, for the community. Do Only Good Everyday.
              </p>
            </div>
          </Card>
        </div>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>DogeMoon Wallet is not affiliated with Dogecoin Foundation.</p>
          <p className="mt-2">This is an open-source project.</p>
        </div>
      </main>
    </div>
  )
}
