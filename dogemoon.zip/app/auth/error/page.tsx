import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DogeLogo } from "@/components/doge-logo"
import { AlertCircle } from "lucide-react"

export default async function AuthErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>
}) {
  const params = await searchParams

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
      <Card className="w-full max-w-md border-border text-center">
        <CardHeader className="space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
              <AlertCircle className="w-8 h-8 text-destructive" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Authentication Error</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            {params.error || "An error occurred during authentication. Please try again."}
          </p>
          <div className="flex gap-3">
            <Link href="/auth/login" className="flex-1">
              <Button variant="outline" className="w-full h-12 bg-transparent">
                Back to Login
              </Button>
            </Link>
            <Link href="/auth/signup" className="flex-1">
              <Button className="w-full h-12">Sign Up</Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      <div className="mt-8 flex items-center gap-2 text-muted-foreground">
        <DogeLogo className="w-6 h-6" />
        <span className="text-sm">DogeMoon Wallet</span>
      </div>
    </div>
  )
}
