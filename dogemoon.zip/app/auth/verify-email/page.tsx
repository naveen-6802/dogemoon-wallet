import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DogeLogo } from "@/components/doge-logo"
import { Mail } from "lucide-react"

export default function VerifyEmailPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
      <Card className="w-full max-w-md border-border text-center">
        <CardHeader className="space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Mail className="w-8 h-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Check Your Email</CardTitle>
          <CardDescription className="text-base">
            We&apos;ve sent a verification link to your email address. Please click the link to verify your account.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted rounded-lg p-4 text-sm text-muted-foreground">
            <p>Didn&apos;t receive the email? Check your spam folder or try signing up again.</p>
          </div>
          <Link href="/auth/login">
            <Button variant="outline" className="w-full h-12 bg-transparent">
              Back to Login
            </Button>
          </Link>
        </CardContent>
      </Card>

      <div className="mt-8 flex items-center gap-2 text-muted-foreground">
        <DogeLogo className="w-6 h-6" />
        <span className="text-sm">DogeMoon Wallet</span>
      </div>
    </div>
  )
}
