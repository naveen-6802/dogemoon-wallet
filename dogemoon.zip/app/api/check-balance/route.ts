import { createClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"

export async function POST(request: Request) {
  try {
    const { address } = await request.json()

    // Verify user is authenticated
    const cookieStore = await cookies()
    const supabase = createClient(cookieStore)
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Fetch balance from blockchain API (API key hidden on server)
    const response = await fetch(
      `https://block.io/api/v2/get_address_balance/?api_key=${process.env.BLOCK_IO_API_KEY}&addresses=${address}`,
    )

    if (!response.ok) {
      throw new Error("Failed to fetch balance")
    }

    const data = await response.json()

    if (data.status === "success") {
      const balance = Number.parseFloat(data.data.addresses[0].balance)
      return Response.json({ success: true, balance })
    }

    throw new Error("Failed to fetch address balance")
  } catch (error) {
    console.error("Check balance error:", error)
    return Response.json({ error: error instanceof Error ? error.message : "Failed to check balance" }, { status: 500 })
  }
}
