import { createClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"

export async function POST(request: Request) {
  try {
    const { from_address, to_address, private_key } = await request.json()

    // Verify user is authenticated
    const cookieStore = await cookies()
    const supabase = createClient(cookieStore)
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Broadcast transaction via BlockIO API (API key hidden on server)
    const response = await fetch("https://block.io/api/v2/sweep_from_address/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: process.env.BLOCK_IO_API_KEY, // API key is now secure on server
        from_address,
        to_address,
        private_key,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to broadcast transaction")
    }

    const result = await response.json()

    if (result.status === "success") {
      // Log to Supabase for transaction history
      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "sweep",
        from_address,
        to_address,
        amount: result.data.amount,
        fee: result.data.fee,
        tx_hash: result.data.txid,
        status: "confirmed",
      })

      return Response.json({ success: true, txid: result.data.txid })
    }

    throw new Error("Transaction broadcast failed")
  } catch (error) {
    console.error("Sweep wallet error:", error)
    return Response.json({ error: error instanceof Error ? error.message : "Failed to sweep wallet" }, { status: 500 })
  }
}
