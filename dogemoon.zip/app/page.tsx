"use client"

import { useState } from "react"
import { useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DogeLogo } from "@/components/doge-logo"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Info,
  Shield,
  Key,
  ExternalLink,
  Heart,
  Copy,
  Check,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Mail,
  Twitter,
  Sun,
  Moon,
} from "lucide-react"
import { useTheme } from "@/contexts/theme-context"

const FAQS = [
  {
    question: "Why is my wallet locked?",
    answer:
      "Your wallet is locked for your security. To send Dogecoin, you must 'unlock' the wallet by entering your 12-word recovery phrase. This ensures that even if someone has access to your logged-in account or PIN, they cannot move your funds without the physical recovery phrase.",
  },
  {
    question: "How do I unlock my wallet?",
    answer:
      "Go to Settings > Backup Wallet > Click on Import Wallet > Enter Your Recovery Phrase > Import wallet. This is due to security purpose, whenever you sign out and sign in into new device/new session, it always asks your seed phrase because we do not store it on our servers. Once unlocked, the mnemonic is stored only in your active session memory (localStorage) to allow transaction signing. It will lock again when you sign out.",
  },
  {
    question: "Is DogeMoon Wallet safe to use?",
    answer:
      "Yes. DogeMoon is a self-custodial wallet. Your private keys and recovery phrases never leave your device and are never stored on our servers. Transactions are signed locally. We only store your public address and a hashed version of your PIN for app access.",
  },
  {
    question: "What happens if I lose my recovery phrase?",
    answer:
      "If you lose your 12-word recovery phrase, your funds are permanently lost. We do not have a copy of your phrase and cannot reset it for you. Always keep multiple offline backups of your phrase.",
  },
  {
    question: "Can I use my DogeMoon phrase in other wallets?",
    answer:
      "Absolutely. DogeMoon uses standard BIP39 mnemonics and BIP44 derivation paths. You can import your 12 words into Trust Wallet, Ledger, or any other compatible wallet to access your DOGE.",
  },
  {
    question: "Do you store my PIN?",
    answer:
      "We store a secure, cryptographic hash of your PIN in our database to verify your identity when you open the app. The actual PIN is never stored in plain text.",
  },
  {
    question: "Why do I need to re-import my wallet on a new device?",
    answer:
      "Since we don't store your recovery phrase for security reasons, your new device has no way of knowing your private keys. You must manually import your phrase once on every new device you use.",
  },
  {
    question: "Where are my Dogecoins actually kept?",
    answer:
      "Your Dogecoins live on the Dogecoin blockchain. The wallet app is just a window that allows you to interact with those funds using your private keys.",
  },
  {
    question: "Are there any fees?",
    answer:
      "DogeMoon doesn't charge any service fees. You only pay the standard Dogecoin network miners' fee, which we've optimized to be as low as possible (approx. 0.01 DOGE).",
  },
  {
    question: "Is this affiliated with the Dogecoin Foundation?",
    answer:
      "No. DogeMoon Wallet is an independent project created by the community for the community. We are not affiliated with the Dogecoin Foundation or any exchange.",
  },
]

export default function LandingPage() {
  const [showAbout, setShowAbout] = useState(false)
  const [showDonate, setShowDonate] = useState(false)
  const [showFAQ, setShowFAQ] = useState(false)
  const [showContact, setShowContact] = useState(false)
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null)
  const [copied, setCopied] = useState(false)
  const { theme, toggleTheme } = useTheme()

  const copyAddress = () => {
    navigator.clipboard.writeText("D775iKxVWVdYLu93yPNiMFATGLxvEvoYPh")
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  useEffect(() => {
    const style = document.createElement("style")
    style.setAttribute("type", "text/css")
    style.innerHTML = `
      #v0-built-with-button-57e6441f-73f2-4503-9d3b-c31e1fe0144a {
        display: none !important;
        visibility: hidden !important;
        pointer-events: none !important;
        opacity: 0 !important;
      }
    `
    document.head.appendChild(style)
  }, [])

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="absolute top-4 right-4">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full w-10 h-10 bg-card border-border hover:bg-accent"
        >
          {theme === "dark" ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-slate-700" />}
        </Button>
      </div>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-12">
        <div className="text-center max-w-md mx-auto space-y-8">
          {/* Logo */}
          <div className="flex justify-center">
            <DogeLogo className="w-32 h-32" />
          </div>

          {/* Title */}
          <div className="space-y-3">
            <h1 className="text-4xl font-bold tracking-tight text-foreground">
              DogeMoon <span className="text-primary">Wallet</span>
            </h1>
            <p className="text-muted-foreground text-lg">The secure, self-custodial Dogecoin experience.</p>
          </div>

          {/* Features */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="text-primary font-semibold mb-1">Self-Custodial</div>
              <p className="text-muted-foreground text-xs">Your keys never leave your device</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="text-primary font-semibold mb-1">Secure</div>
              <p className="text-muted-foreground text-xs">PIN protected with encryption</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="text-primary font-semibold mb-1">Easy Backup</div>
              <p className="text-muted-foreground text-xs">12-word recovery phrase</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="text-primary font-semibold mb-1">Scan & Pay</div>
              <p className="text-muted-foreground text-xs">QR code for quick transfers</p>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="space-y-3 pt-4">
            <Link href="/auth/login" className="block">
              <Button className="w-full h-12 text-base font-semibold bg-primary hover:bg-primary/90">Wallet</Button>
            </Link>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => setShowAbout(true)}
                className="h-12 text-sm font-semibold bg-transparent"
              >
                <Info className="w-4 h-4 mr-2" />
                About
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowContact(true)}
                className="h-12 text-sm font-semibold bg-transparent"
              >
                <Mail className="w-4 h-4 mr-2" />
                Contact
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Join the DogeMoon wallet and pay securely. </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-6 px-4 text-center space-y-4 border-t border-border">
        <div className="flex flex-wrap justify-center gap-4 text-xs text-muted-foreground mb-2">
          <Button
            variant="link"
            onClick={() => setShowFAQ(true)}
            className="h-auto p-0 text-muted-foreground hover:text-primary text-xs"
          >
            FAQ
          </Button>
          <span className="text-border">|</span>
          <a
            href="https://naveen-6802.github.io"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-primary transition-colors font-semibold"
          >
            Developer
          </a>
          <span className="text-border">|</span>
          <a
            href="https://github.com/naveen-6802/dogemoon-wallet"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-primary transition-colors font-semibold"
          >
            Open Source
          </a>
        </div>

        <div className="flex justify-center">
          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs gap-2 bg-transparent"
            onClick={() => setShowDonate(true)}
          >
            <Heart className="w-3 h-3 text-red-500 fill-red-500" />
            Donate DOGE
          </Button>
        </div>

        <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
          DogeMoon Wallet - Not affiliated with Dogecoin Foundation
        </p>
      </footer>

      {/* Donation Dialog */}
      <Dialog open={showDonate} onOpenChange={setShowDonate}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500 fill-red-500" />
              Support DogeMoon Wallet
            </DialogTitle>
            <DialogDescription className="text-left pt-2">
              Your donations keep us running! DogeMoon is an independent project, and every bit of DOGE helps us
              maintain the infrastructure, pay for APIs, and continue building the best self-custodial experience for
              the community.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="bg-muted p-4 rounded-xl border border-border">
              <p className="text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wider">
                Donation Address
              </p>
              <div className="flex items-center justify-between gap-2">
                <code className="text-xs font-mono break-all text-foreground">D775iKxVWVdYLu93yPNiMFATGLxvEvoYPh</code>
                <Button size="icon" variant="ghost" className="shrink-0" onClick={copyAddress}>
                  {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>
            <p className="text-[10px] text-center text-muted-foreground italic">
              Much Wow! Thank you for your support! 🚀🌕
            </p>
          </div>
          <DialogFooter>
            <Button className="w-full" onClick={() => setShowDonate(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* About Dialog */}
      <Dialog open={showAbout} onOpenChange={setShowAbout}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <DogeLogo className="w-8 h-8" />
              About DogeMoon Wallet
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* What is DogeMoon */}
            <section>
              <h3 className="font-semibold text-foreground mb-2">What is DogeMoon Wallet?</h3>
              <p className="text-sm text-muted-foreground">
                DogeMoon Wallet is a self-custodial Dogecoin wallet that gives you full control over your
                cryptocurrency. Unlike custodial wallets, we never have access to your funds or private keys.
              </p>
            </section>

            {/* Self-Custodial Explained */}
            <section className="bg-primary/5 border border-primary/20 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Key className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-semibold text-foreground mb-1">Self-Custodial = You Own Your Keys</h4>
                  <p className="text-sm text-muted-foreground">
                    Your 12-word recovery phrase is the only way to access your wallet. We never store it on our
                    servers. If you lose it, your funds cannot be recovered by anyone - including us.
                  </p>
                </div>
              </div>
            </section>

            {/* Blockchain Storage Note */}
            <section className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-semibold text-foreground mb-1 text-blue-500">Blockchain Storage</h4>
                  <p className="text-sm text-muted-foreground">
                    Your dogecoins are stored on the Dogecoin blockchain, not on our database. If our website is ever
                    unavailable, you can always access your funds using your recovery phrase in any other Dogecoin
                    wallet (like Trust Wallet or Binance Wallet).
                  </p>
                </div>
              </div>
            </section>

            {/* How to Use */}
            <section>
              <h3 className="font-semibold text-foreground mb-3">Complete Setup Process</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shrink-0">
                    1
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Sign Up & Secure Access</p>
                    <p className="text-xs text-muted-foreground">
                      Create an account with your email. You&apos;ll be asked to set a 6-digit PIN. This PIN is hashed
                      and stored securely to protect your app access on this device.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shrink-0">
                    2
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Create or Import Wallet</p>
                    <p className="text-xs text-muted-foreground">
                      If you&apos;re new, create a wallet to generate your 12-word recovery phrase. If you already have
                      one, choose &quot;Import&quot; and enter your existing phrase.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shrink-0">
                    3
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Multi-Device Usage</p>
                    <p className="text-xs text-muted-foreground">
                      DogeMoon is self-custodial. If you sign in on a different device, you MUST import your wallet
                      again using your 12-word recovery phrase. We don&apos;t sync your keys for your security.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shrink-0">
                    4
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Backup is Everything</p>
                    <p className="text-xs text-muted-foreground">
                      Write down your 12 words and store them safely offline. This is the ONLY way to recover your DOGE
                      if you lose your phone or forget your PIN.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Security */}
            <section className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-green-500 mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-semibold text-foreground mb-1">Security First</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Recovery phrase never stored on servers</li>
                    <li>• PIN is securely hashed before storage</li>
                    <li>• All transactions signed locally on your device</li>
                    <li>• Open source and transparent</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Terms */}
            <section>
              <h3 className="font-semibold text-foreground mb-2">Terms of Service</h3>
              <p className="text-sm text-muted-foreground mb-2">
                By using DogeMoon Wallet, you agree to our terms including:
              </p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• You are responsible for securing your recovery phrase</li>
                <li>• We cannot recover lost funds or phrases</li>
                <li>• Use at your own risk - we are not liable for losses</li>
              </ul>
              <Link href="/wallet/terms" className="text-sm text-primary hover:underline mt-2 inline-block">
                Read Full Terms →
              </Link>
            </section>

            {/* Creator */}
            <section className="border-t border-border pt-4">
              <h3 className="font-semibold text-foreground mb-2">Created By</h3>
              <p className="text-sm text-muted-foreground">
                DogeMoon Wallet was created by{" "}
                <a
                  href="https://naveen-6802.github.io"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline font-medium inline-flex items-center gap-1"
                >
                  Naveen Soni
                  <ExternalLink className="w-3 h-3" />
                </a>
              </p>
            </section>
          </div>
        </DialogContent>
      </Dialog>

      {/* FAQ Dialog */}
      <Dialog open={showFAQ} onOpenChange={setShowFAQ}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-primary" />
              Frequently Asked Questions
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-4">
            {FAQS.map((faq, index) => (
              <div key={index} className="border border-border rounded-lg overflow-hidden">
                <button
                  className="w-full p-4 flex items-center justify-between text-left bg-card hover:bg-accent/50 transition-colors"
                  onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                >
                  <span className="text-sm font-medium text-foreground">{faq.question}</span>
                  {openFaqIndex === index ? (
                    <ChevronUp className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  )}
                </button>
                {openFaqIndex === index && (
                  <div className="p-4 bg-muted/30 border-t border-border">
                    <p className="text-sm text-muted-foreground leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button className="w-full" onClick={() => setShowFAQ(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Contact Dialog */}
      <Dialog open={showContact} onOpenChange={setShowContact}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-primary" />
              Contact Developer
            </DialogTitle>
            <DialogDescription>
              Have questions or need support? Feel free to reach out via email or Twitter.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <a
              href="mailto:naveen6802@gmail.com"
              className="flex items-center gap-4 p-4 rounded-xl bg-muted/50 border border-border hover:border-primary/30 transition-all group"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Email</p>
                <p className="font-medium">naveen6802@gmail.com</p>
              </div>
            </a>

            <a
              href="https://twitter.com/naveen6802"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 rounded-xl bg-muted/50 border border-border hover:border-primary/30 transition-all group"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Twitter className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Twitter / X</p>
                <p className="font-medium">@naveen6802</p>
              </div>
            </a>
          </div>

          <DialogFooter>
            <Button className="w-full" onClick={() => setShowContact(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
