import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNumber(num: number, decimals = 2): string {
  return num.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

// Format large numbers with abbreviations (K, M, B, T)
export function formatLargeNumber(num: number, decimals = 2): string {
  if (num >= 1e12) return `${(num / 1e12).toFixed(decimals)}T`
  if (num >= 1e9) return `${(num / 1e9).toFixed(decimals)}B`
  if (num >= 1e6) return `${(num / 1e6).toFixed(decimals)}M`
  if (num >= 1e3) return `${(num / 1e3).toFixed(decimals)}K`
  return num.toLocaleString(undefined, { maximumFractionDigits: decimals })
}

// Format currency with abbreviations
export function formatCurrency(num: number, decimals = 2): string {
  if (num >= 1e12) return `$${(num / 1e12).toFixed(decimals)}T`
  if (num >= 1e9) return `$${(num / 1e9).toFixed(decimals)}B`
  if (num >= 1e6) return `$${(num / 1e6).toFixed(decimals)}M`
  return `$${num.toLocaleString(undefined, { maximumFractionDigits: decimals })}`
}
