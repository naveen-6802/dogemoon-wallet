// Dogecoin Wallet Cryptography Library
// Uses BIP39 for mnemonic generation and BIP44 for Dogecoin derivation

import * as bip39 from "bip39"
import { BIP32Factory } from "bip32"
import * as ecc from "tiny-secp256k1"
import { payments, type networks } from "bitcoinjs-lib"
import bs58check from "bs58check"
import { ECPairFactory } from "ecpair"

// Initialize BIP32 with secp256k1
const bip32 = BIP32Factory(ecc)

// Initialize ECPair with secp256k1
const ECPair = ECPairFactory(ecc)

// Dogecoin network parameters
export const dogecoinNetwork = {
  messagePrefix: "\x19Dogecoin Signed Message:\n",
  bech32: "doge",
  bip32: {
    public: 0x02facafd,
    private: 0x02fac398,
  },
  pubKeyHash: 0x1e, // D prefix
  scriptHash: 0x16,
  wif: 0x9e,
}

// Generate a new 12-word mnemonic
export function generateMnemonic(): string {
  return bip39.generateMnemonic(128) // 128 bits = 12 words
}

// Validate a mnemonic phrase
export function validateMnemonic(mnemonic: string): boolean {
  return bip39.validateMnemonic(mnemonic)
}

// Derive Dogecoin wallet from mnemonic
// BIP44 path for Dogecoin: m/44'/3'/0'/0/0
export async function deriveWalletFromMnemonic(mnemonic: string): Promise<{
  address: string
  privateKey: string
  publicKey: string
}> {
  if (!validateMnemonic(mnemonic)) {
    throw new Error("Invalid mnemonic phrase")
  }

  const seed = await bip39.mnemonicToSeed(mnemonic)
  const root = bip32.fromSeed(seed)

  // Dogecoin BIP44 derivation path: m/44'/3'/0'/0/0
  const child = root.derivePath("m/44'/3'/0'/0/0")

  if (!child.privateKey) {
    throw new Error("Failed to derive private key")
  }

  // Generate Dogecoin address from public key
  const address = generateDogecoinAddress(child.publicKey)

  // Convert private key to WIF format
  const privateKeyWIF = toWIF(child.privateKey)

  return {
    address,
    privateKey: privateKeyWIF,
    publicKey: Buffer.from(child.publicKey).toString("hex"),
  }
}

// Generate Dogecoin address from public key
function generateDogecoinAddress(publicKey: Uint8Array): string {
  const { address } = payments.p2pkh({
    pubkey: Buffer.from(publicKey),
    network: dogecoinNetwork as unknown as networks.Network,
  })

  if (!address) {
    throw new Error("Failed to generate address")
  }

  return address
}

// Convert private key to Wallet Import Format (WIF)
function toWIF(privateKey: Uint8Array): string {
  const prefix = Buffer.from([dogecoinNetwork.wif])
  const suffix = Buffer.from([0x01]) // Compressed
  const data = Buffer.concat([prefix, Buffer.from(privateKey), suffix])
  return bs58check.encode(data)
}

// Validate a Dogecoin address
export function validateDogecoinAddress(address: string): boolean {
  try {
    // Dogecoin addresses start with 'D' or 'A' (for multisig)
    if (!address.match(/^[DA][1-9A-HJ-NP-Za-km-z]{25,34}$/)) {
      return false
    }

    // Verify checksum with bs58check
    const decoded = bs58check.decode(address)
    return decoded[0] === dogecoinNetwork.pubKeyHash || decoded[0] === dogecoinNetwork.scriptHash
  } catch {
    return false
  }
}

// Simple PIN hashing (in production, use bcrypt on server)
export async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(pin + "dogemoon_salt_2024")
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}

// Verify PIN against hash
export async function verifyPin(pin: string, hash: string): Promise<boolean> {
  const pinHash = await hashPin(pin)
  return pinHash === hash
}

// Derives a Dogecoin address from a WIF private key
export function getAddressFromWIF(wif: string): string {
  try {
    const keyPair = ECPair.fromWIF(wif, dogecoinNetwork as any)
    const { address } = payments.p2pkh({
      pubkey: keyPair.publicKey,
      network: dogecoinNetwork as any,
    })
    if (!address) throw new Error("Could not derive address")
    return address
  } catch (error) {
    console.error("WIF derivation error:", error)
    throw new Error("Invalid WIF private key")
  }
}

// Signs a transaction skeleton using a WIF private key
export function signTransactionWithWIF(txSkeleton: any, wif: string): string[] {
  try {
    const keyPair = ECPair.fromWIF(wif, dogecoinNetwork as any)
    return txSkeleton.tosign.map((tosign: string) => {
      const signature = keyPair.sign(Buffer.from(tosign, "hex"))
      // BlockCypher expects DER encoded signature + SIGHASH_ALL
      return Buffer.concat([signature, Buffer.from([0x01])]).toString("hex")
    })
  } catch (error) {
    console.error("WIF signing error:", error)
    throw new Error("Failed to sign transaction with WIF")
  }
}
