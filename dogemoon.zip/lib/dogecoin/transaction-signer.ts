// Transaction signing utilities for Dogecoin
import * as ecc from "tiny-secp256k1"
import { BIP32Factory } from "bip32"
import * as bip39 from "bip39"

const bip32 = BIP32Factory(ecc)

function toDER(signature: Uint8Array): string {
  // The signature from tiny-secp256k1 is 64 bytes (r: 32 bytes, s: 32 bytes)
  const r = signature.slice(0, 32)
  const s = signature.slice(32, 64)

  // Remove leading zeros but keep at least one byte
  const trimLeadingZeros = (arr: Uint8Array): Uint8Array => {
    let i = 0
    while (i < arr.length - 1 && arr[i] === 0) i++
    return arr.slice(i)
  }

  let rTrimmed = trimLeadingZeros(r)
  let sTrimmed = trimLeadingZeros(s)

  // If high bit is set, prepend 0x00 to indicate positive number
  if (rTrimmed[0] & 0x80) {
    const newR = new Uint8Array(rTrimmed.length + 1)
    newR[0] = 0x00
    newR.set(rTrimmed, 1)
    rTrimmed = newR
  }

  if (sTrimmed[0] & 0x80) {
    const newS = new Uint8Array(sTrimmed.length + 1)
    newS[0] = 0x00
    newS.set(sTrimmed, 1)
    sTrimmed = newS
  }

  // Build DER structure
  const totalLen = 2 + rTrimmed.length + 2 + sTrimmed.length
  const der = new Uint8Array(2 + totalLen)

  let offset = 0
  der[offset++] = 0x30 // SEQUENCE tag
  der[offset++] = totalLen
  der[offset++] = 0x02 // INTEGER tag for r
  der[offset++] = rTrimmed.length
  der.set(rTrimmed, offset)
  offset += rTrimmed.length
  der[offset++] = 0x02 // INTEGER tag for s
  der[offset++] = sTrimmed.length
  der.set(sTrimmed, offset)

  return Buffer.from(der).toString("hex")
}

// Sign transaction hashes with private key derived from mnemonic
export async function signTransaction(
  mnemonic: string,
  tosign: string[],
): Promise<{ signatures: string[]; publicKey: string }> {
  const seed = await bip39.mnemonicToSeed(mnemonic)
  const root = bip32.fromSeed(seed)
  const child = root.derivePath("m/44'/3'/0'/0/0")

  if (!child.privateKey) {
    throw new Error("Failed to derive private key")
  }

  const signatures = tosign.map((hash) => {
    const hashBuffer = Buffer.from(hash, "hex")
    const signature = ecc.sign(hashBuffer, child.privateKey!)
    return toDER(signature)
  })

  return {
    signatures,
    publicKey: Buffer.from(child.publicKey).toString("hex"),
  }
}
