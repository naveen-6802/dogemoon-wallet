// Dogecoin Blockchain API interactions
// Using BlockCypher API for balance, transactions, and broadcasting

const BLOCKCYPHER_BASE = "https://api.blockcypher.com/v1/doge/main"

export interface Transaction {
  hash: string
  type: "sent" | "received"
  amount: number
  confirmations: number
  timestamp: string
  address: string
}

export interface WalletBalance {
  balance: number
  unconfirmedBalance: number
  totalReceived: number
  totalSent: number
}

// Get wallet balance
export async function getWalletBalance(address: string): Promise<WalletBalance> {
  try {
    const response = await fetch(`${BLOCKCYPHER_BASE}/addrs/${address}/balance`, {
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error("Failed to fetch balance")
    }

    const data = await response.json()

    return {
      balance: data.balance / 100000000,
      unconfirmedBalance: data.unconfirmed_balance / 100000000,
      totalReceived: data.total_received / 100000000,
      totalSent: data.total_sent / 100000000,
    }
  } catch (error) {
    console.error("Error fetching balance:", error)
    return {
      balance: 0,
      unconfirmedBalance: 0,
      totalReceived: 0,
      totalSent: 0,
    }
  }
}

export async function getTransactionHistory(address: string): Promise<Transaction[]> {
  try {
    const response = await fetch(`${BLOCKCYPHER_BASE}/addrs/${address}/full?limit=50`)

    if (!response.ok) {
      throw new Error("Failed to fetch transactions")
    }

    const data = await response.json()

    if (!data.txs) {
      return []
    }

    return data.txs.map((tx: any) => {
      // Check if our address is in inputs (we're sending)
      const isSender = tx.inputs?.some((inp: any) => inp.addresses?.includes(address))

      // Calculate total input from our address
      const totalInputFromUs =
        tx.inputs
          ?.filter((inp: any) => inp.addresses?.includes(address))
          .reduce((sum: number, inp: any) => sum + (inp.output_value || 0), 0) || 0

      // Calculate total output back to our address (change)
      const totalOutputToUs =
        tx.outputs
          ?.filter((out: any) => out.addresses?.includes(address))
          .reduce((sum: number, out: any) => sum + out.value, 0) || 0

      // Calculate total output to others
      const totalOutputToOthers =
        tx.outputs
          ?.filter((out: any) => !out.addresses?.includes(address))
          .reduce((sum: number, out: any) => sum + out.value, 0) || 0

      let amount = 0
      let type: "sent" | "received" = "received"
      let otherAddress = ""

      if (isSender) {
        // We're the sender - amount is what we sent to others (not including change back to us)
        type = "sent"
        amount = totalOutputToOthers
        // Get the recipient address (first output not to us)
        otherAddress = tx.outputs?.find((out: any) => !out.addresses?.includes(address))?.addresses?.[0] || ""
      } else {
        // We're the receiver
        type = "received"
        amount = totalOutputToUs
        // Get the sender address
        otherAddress = tx.inputs?.[0]?.addresses?.[0] || ""
      }

      return {
        hash: tx.hash,
        type,
        amount: amount / 100000000,
        confirmations: tx.confirmations || 0,
        timestamp: tx.confirmed || tx.received,
        address: otherAddress,
      }
    })
  } catch (error) {
    console.error("Error fetching transactions:", error)
    return []
  }
}

// Get DOGE price in USD
export async function getDogecoinPrice(): Promise<number> {
  try {
    const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=dogecoin&vs_currencies=usd")

    if (!response.ok) {
      throw new Error("Failed to fetch price")
    }

    const data = await response.json()
    return data.dogecoin?.usd || 0
  } catch (error) {
    console.error("Error fetching price:", error)
    return 0
  }
}

export async function createTransaction(fromAddress: string, toAddress: string, amount: number): Promise<any> {
  const amountSatoshis = Math.floor(amount * 100000000)
  // Minimum fee for Dogecoin is 0.01 DOGE (1,000,000 koinu)
  const minFee = 1000000 // 0.01 DOGE

  const response = await fetch(`${BLOCKCYPHER_BASE}/txs/new`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      inputs: [{ addresses: [fromAddress] }],
      outputs: [{ addresses: [toAddress], value: amountSatoshis }],
      preference: "low",
      fees: minFee,
    }),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.error || error.errors?.[0]?.error || "Failed to create transaction")
  }

  return response.json()
}

export async function broadcastTransaction(
  txSkeleton: any,
  signatures: string[],
  publicKeys: string[],
): Promise<{ hash: string }> {
  const pubkeys = signatures.map(() => publicKeys[0])

  const payload = {
    tx: txSkeleton.tx,
    tosign: txSkeleton.tosign,
    signatures: signatures,
    pubkeys: pubkeys,
  }

  const response = await fetch(`${BLOCKCYPHER_BASE}/txs/send`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    const error = await response.json()
    console.error("Broadcast error details:", error)
    throw new Error(error.error || error.errors?.[0]?.error || "Failed to broadcast transaction")
  }

  const result = await response.json()
  return { hash: result.tx.hash }
}
